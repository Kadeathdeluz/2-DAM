package prg;

import utils.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
// SQLite imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mongodb.MongoException;
// MongoDB imports
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.Projections;
import org.bson.Document;

/**
 * ===================================================================== Class
 * to handle CRUD Operations on DB (SQLite and MongoDB)
 * 
 * @author Roldán Sanchis Martínez. Based and modified from Abelardo Mart�nez
 *         =====================================================================
 */
public class TaxInspectorManagerDB {

	/**
	 * ---------------------------------------- GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */

	// Object name constant
	static final String OBJNAME = "Taxinspector";
	// Just to avoid mistakes, table name constant (same as object name)
	static final String OBJTABLE_NAME = OBJNAME;
	// Just to avoid mistakes, collection name constant (same as object name)
	static final String COLLECTION_NAME = OBJNAME;
	// Date Format
	static final String DATE_FORMAT = "dd/MM/yyyy";

	// DB constants

	// URL to connect to SQLite DB (Windows) "tequitotodo" in honor of BD of 1st
	// year
	static final String SQLITE_URL = "jdbc:sqlite:bdsqlite\\tequitotodo.db";
	// URL to connect to DB (Linux)
	// static final String URL = "jdbc:sqlite:bdsqlite/tequitotodo.db";

	// URL to connect to MongoDB DB
	static final String MONGODB_URL = "mongodb://localhost:27017";
	// MongoDB database name
	static final String MONGODB_DB_NAME = "temongotodo";

	/**
	 * ---------------------------------------- MANAGE Tax Inspectors
	 * ----------------------------------------
	 */
	/*
	 * ---------------------------------------- INSERT
	 * ----------------------------------------
	 */

	/*
	 * Get tax inspectors list from keyboard. Checks if the ID already exists in the
	 * array.
	 */
	public static ArrayList<TaxInspector> getTaxInspectorListFromKeyboard() {

		ArrayList<TaxInspector> arlTaxInspectors = new ArrayList<TaxInspector>(); // array of TaxInspectors
		String taxInspectorID;
		String firstName;
		String lastName;
		LocalDate birthday;
		Float commission;
		Float commissionPercentage;
		Integer cheatedTaxPayers;
		/*
		 * 1st STEP: We're asking for items until zero is set as ID
		 */
		while (true) {
			// Ask for ID while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				taxInspectorID = IOTools.askString(OBJNAME + " ID (zero to exit)");
				for (TaxInspector taxInspector : arlTaxInspectors) {
					if (taxInspectorID.equals(taxInspector.getTaxInspectorID())) {
						bExists = true;
						System.out.println("====> ERROR: ID already exists");
					}
				}
			} while (bExists);

			if (taxInspectorID.equals("0"))
				break;

			firstName = IOTools.askStringSpaces(OBJNAME + " firstname");
			lastName = IOTools.askStringSpaces(OBJNAME + " lastname");
			birthday = IOTools.askDate(OBJNAME + " birthday", DATE_FORMAT);
			commission = IOTools.askFloat(OBJNAME + " commission");
			commissionPercentage = IOTools.askFloat(OBJNAME + " commission percentage", 0, 30);
			cheatedTaxPayers = IOTools.askInt(OBJNAME + " cheated tax payers");
			/*
			 * 2nd STEP: We create an object (TaxInspector) as soon as we have the right
			 * data of an item
			 */
			TaxInspector objTaxInspector = new TaxInspector(taxInspectorID, firstName, lastName, birthday, commission,
					commissionPercentage, cheatedTaxPayers);

			/*
			 * 3rd STEP: Add the item to the ArrayList
			 */
			arlTaxInspectors.add(objTaxInspector);
			System.out.println("====> Added: " + objTaxInspector.toString());
			System.out.println("");
		}
		/*
		 * 4th STEP: Return the ArrayList
		 */
		return arlTaxInspectors;
	}

	/*
	 * Creates an SQLite DB table with all the items of the ArrayList
	 */
	public static void writeTaxInspectorToSQLiteDB_JDBC(ArrayList<TaxInspector> arlTaxInspector) {
		// TaxInspector object
		TaxInspector objTaxInspector;
		// TaxInspector attributes
		String stTaxInspectorID;
		String stFirstName;
		String stLastName;
		String ldBirthday;
		Float flCommission;
		Float flCommissionPercentage;
		Integer iCheatedTaxPayers;
		// Boolean to drop table first
		boolean bDropTableFirst = true;

		/*
		 * 1st STEP: Connect to database
		 */
		Connection cnDB = connectToSQLiteDB();
		try {
			Statement staSQLquery = cnDB.createStatement();
			createTableIfNotExists(staSQLquery, bDropTableFirst);
			// Iterate through the ArrayList with an iterator
			Iterator<TaxInspector> itTaxInspector = arlTaxInspector.iterator();
			/*
			 * 2nd STEP: For every item, add a row
			 */
			while (itTaxInspector.hasNext()) {
				// Object
				objTaxInspector = (TaxInspector) (itTaxInspector.next());
				// Attributes
				stTaxInspectorID = objTaxInspector.getTaxInspectorID();
				stFirstName = objTaxInspector.getFirstName();
				stLastName = objTaxInspector.getLastName();
				// Need to ensure the correct format for LocalDate (cast from LD to Str and from
				// Str to LD with the correct format)
				ldBirthday = objTaxInspector.getBirthday().format(DateTimeFormatter.ofPattern(DATE_FORMAT));
				flCommission = objTaxInspector.getCommission();
				flCommissionPercentage = objTaxInspector.getCommissionPercentage();
				iCheatedTaxPayers = objTaxInspector.getCheatedTaxPayers();

				staSQLquery.executeUpdate("INSERT INTO " + OBJTABLE_NAME + " VALUES ('" + stTaxInspectorID + "', '"
						+ stFirstName + "', '" + stLastName + "', '" + ldBirthday + "', " + flCommission + ", "
						+ flCommissionPercentage + ", " + iCheatedTaxPayers + ")");
				System.out.println("Inserted row in given database, table " + OBJTABLE_NAME + "...");
			}
			staSQLquery.close(); // close the statement

		} catch (SQLException sqle) {
			System.out.println("Something was wrong while populating the table!");
			sqle.printStackTrace(System.out);
		}
		closeSQLiteDB(cnDB); // close the connection to the DB
	}

	/*
	 * ----------------------------------- PRINT -----------------------------------
	 */
	/*
	 * Reads the DB table with all the items Since "SELECT IF EXISTS" is not
	 * available... we do "CREATE IF NOT EXISTS" and then "SELECT..."
	 */
	public static void printTaxInspectorFromSQLiteDB_JDBC() {
		/*
		 * 1st STEP: Connect to SQLite database
		 */
		Connection cnDB = connectToSQLiteDB();
		try {
			Statement staSQLquery = cnDB.createStatement();
			/*
			 * 2nd STEP: Check if the table exists. Otherwise, drop and create it again
			 */
			boolean bDropTableFirst = false;
			createTableIfNotExists(staSQLquery, bDropTableFirst);
			/*
			 * 3rd STEP: For every item, print it
			 */
			// Select all tax inspectors
			String stSQLSelect = "SELECT ID, firstName, lastName, birthday, commission, commissionPercentage, cheatedTaxPayers FROM "
					+ OBJTABLE_NAME;
			System.out.println("Executing: " + stSQLSelect + "...\n");
			// return all records to the result set
			ResultSet rsTaxInspector = staSQLquery.executeQuery(stSQLSelect);
			int iNumTaxInspector = 0;
			
			while (rsTaxInspector.next()) {
				iNumTaxInspector++;
				// Print every attribute of the current TaxInspector row
				System.out.println(OBJTABLE_NAME + " ID: " + rsTaxInspector.getString("ID"));
				System.out.println(OBJTABLE_NAME + " First Name: " + rsTaxInspector.getString("firstName"));
				System.out.println(OBJTABLE_NAME + " Last Name: " + rsTaxInspector.getString("lastName"));
				System.out.println(OBJTABLE_NAME + " Birthday: " + rsTaxInspector.getString("birthday"));
				System.out.println(OBJTABLE_NAME + " Commission: " + rsTaxInspector.getFloat("commission") + "€");
				System.out.println(
						OBJTABLE_NAME + " Commission (%): " + rsTaxInspector.getFloat("commissionPercentage") + "%");
				System.out.println(OBJTABLE_NAME + " Cheated TaxPayers: " + rsTaxInspector.getInt("cheatedTaxPayers"));
				System.out.println("");
			}
			if (iNumTaxInspector == 0) {
				System.out.println("No items found on table " + OBJTABLE_NAME);
			}
			// Then, close RS and St
			rsTaxInspector.close(); // close the ResultSet
			staSQLquery.close(); // close the statement

		} catch (SQLException sqle) {
			System.out.println("Something was wrong while reading the table " + OBJTABLE_NAME);
			sqle.printStackTrace(System.out);
		}
		closeSQLiteDB(cnDB); // Finally, close the connection to the SQLite DB
	}

	/*
	 * Print TaxInspectors from MongoDB DB
	 */
	public static void printTaxInspectorFromMongoDBDB_JDBC() {
		// Get the MongoDB client for connecting to database
		MongoClient cnDB = connectToMongoDBDB();
		
		try {
			// Establish the connection to database
			MongoDatabase mDB = cnDB.getDatabase(MONGODB_DB_NAME);
			
			MongoCollection<Document> mCollection = mDB.getCollection(COLLECTION_NAME);
			// Retrieving the documents
			MongoCursor<Document> mCursor = mCollection.find().projection(Projections.excludeId()).iterator();
			
			int iNumItems = 0;
			while (mCursor.hasNext()) {
				iNumItems++;
				Document docEmployee = mCursor.next();
				System.out.println(OBJNAME);
				System.out.println("Tax Inspector ID: " + (String) docEmployee.get("taxinspectorID"));
				System.out.println("First name: " + (String) docEmployee.get("firstname"));
				System.out.println("Last name: " + (String) docEmployee.get("lastname"));
				System.out.println("Birthday: " + (String) docEmployee.get("birthday"));
				System.out.println("Commission: " + (String) docEmployee.get("commission"));
				System.out.println("Commission (%): " + (String) docEmployee.get("commpercentage"));
				System.out.println("Cheated Tax Payers: " + (String) docEmployee.get("cheatedtaxpayers"));
				System.out.println("");
			}
			if (iNumItems == 0)
				System.out.println("No items found on collection " + COLLECTION_NAME);
			mCursor.close(); // close cursor
			createCollectionIfNotExists(mDB);
		} catch (Exception exe) {
			System.out.println("Something went wrong!");
			exe.printStackTrace(System.out);
		}
		closeMongoDBDB(cnDB);

	}

	/*
	 * ----------------------------------- DELETE
	 * -----------------------------------
	 */
	/*
	 * Delete all items from given table Since "DELETE IF EXISTS" is not
	 * available... we do "CREATE IF NOT EXISTS" and then "DELETE ..."
	 */
	public static void deleteTaxInspectorFromSQLiteDB() {

		/*
		 * 1st STEP: Connect to database
		 */
		Connection cnDB = connectToSQLiteDB();
		try {
			Statement staSQLquery = cnDB.createStatement();
			/*
			 * 2nd STEP: Check if the table exists. Otherwise, drop and create it again
			 */
			boolean bDropTableFirst = false;
			createTableIfNotExists(staSQLquery, bDropTableFirst);
			/*
			 * 3rd STEP: Do truncate
			 */
			String stSQLDelete = "DELETE FROM " + OBJTABLE_NAME;
			System.out.println("Executing: " + stSQLDelete);

			staSQLquery.executeUpdate(stSQLDelete); // delete all the data
			staSQLquery.close(); // close the statement

		} catch (SQLException sqle) {
			System.out.println("Something was wrong while deleting the table " + OBJTABLE_NAME);
			sqle.printStackTrace(System.out);
		}
		closeSQLiteDB(cnDB); // close the connection to the SQLite DB
	}

	/**
	 * ----------------------------------- DATABASE OPERATIONS
	 * -----------------------------------
	 */

	/**
	 * ----------------------------------- DATABASE CONNECT
	 * -----------------------------------
	 */
	/*
	 * Just try to connect to the SQLite database
	 */
	public static Connection connectToSQLiteDB() {

		try {
			Connection cnDB = DriverManager.getConnection(SQLITE_URL);
			System.out.println("Connection to database has been established.");
			return cnDB;
		} catch (SQLException sqle) {
			System.out.println("Something was wrong while trying to connect to the database!");
			sqle.printStackTrace(System.out);
		}
		return null;
	}

	/*
	 * Connect to the MongoDB database
	 */
	public static MongoClient connectToMongoDBDB() {
		try {
			// You can instantiate a MongoClient object without any parameters to connect to
			// a MongoDB instance running on localhost on port 27017:
			MongoClient cnDB = MongoClients.create(MONGODB_URL);
			System.out.println("Connection to database has been established.");
			return cnDB;
		} catch (Exception exe) {
			System.out.println("Something was wrong while trying to connect to the database!");
			exe.printStackTrace(System.out);
		}
		return null;
	}

	/**
	 * ----------------------------------- DATABASE DISCONNECT
	 * -----------------------------------
	 */

	/*
	 * Just try to disconnect to the MongoDB database
	 */
	public static void closeMongoDBDB(MongoClient cnDB) {
		try {
			cnDB.close(); // close connection to the DB
		} catch (Exception exe) {
			System.out.println("Something was wrong while closing the database!");
			exe.printStackTrace(System.out);
		}
	}

	/*
	 * Just try to disconnect to the SQLite DB
	 */
	public static void closeSQLiteDB(Connection cnDB) {

		try {
			cnDB.close(); // close the connection to the DB
		} catch (SQLException sqle) {
			System.out.println("Something was wrong while closing the database!");
			sqle.printStackTrace(System.out);
		}
	}

	/**
	 * ----------------------------------- DDL OPERATIONS
	 * -----------------------------------
	 */

	/*
	 * Create table if not exists. Otherwise, drop table (SQLite)
	 */
	public static void createTableIfNotExists(Statement staSQLquery, boolean bDropFirst) {
		try {
			if (bDropFirst) {
				// Drop table
				String stSQLDrop = "DROP TABLE IF EXISTS " + OBJTABLE_NAME;
				staSQLquery.executeUpdate(stSQLDrop);
				System.out.println("Dropped table " + OBJTABLE_NAME + " (IF EXISTS) in given database.");
			}
			// Create table
			String stSQLCreate = "CREATE TABLE IF NOT EXISTS " + OBJTABLE_NAME + " (" + "ID TEXT, " + "firstName TEXT, "
					+ "lastName TEXT, " + "birthDay TEXT, " + "commission REAL, " + "commissionPercentage REAL, "
					+ "cheatedTaxPayers INTEGER, " + "PRIMARY KEY (ID))";
			staSQLquery.executeUpdate(stSQLCreate);
			if (bDropFirst)
				System.out.println("Created table " + OBJTABLE_NAME + " (IF NOT EXISTS) in given database.");

		} catch (SQLException sqle) {
			System.out.println("Something was wrong when dropping and creating the table!");
			sqle.printStackTrace(System.out);
		}
	}

	/*
	 * Check if collection exists
	 */
	public static boolean collectionExists(String stCollection, MongoDatabase mDB) {
		MongoIterable<String> mitCollection = mDB.listCollectionNames();
		for (String stIterCollection : mitCollection) {
			if (stIterCollection.equals(stCollection)) {
				return true;
			}
		}
		return false;
	}

	/*
	 * Create collection if not exists
	 */
	public static void createCollectionIfNotExists(MongoDatabase mDB) {
		try {
			if (!(collectionExists(COLLECTION_NAME, mDB))) {
				System.out.println("Collection does not exist");
				mDB.createCollection(COLLECTION_NAME);
				System.out.println("Created collection " + COLLECTION_NAME + "in given database...");
			}
		} catch (Exception exe) {
			System.out.println("Something was wrong when creating the collection!");
			exe.printStackTrace(System.out);
		}
	}

	/**
	 * ----------------------------------- DUMPING
	 * -----------------------------------
	 */

	/**
	 * Get data from SQLite DB into an ArrayList of TaxInspectors
	 */
	public static ArrayList<TaxInspector> getTaxInspectorsFromSQLiteDB() {
		// Temporal ArrayList of TaxInspectors
		ArrayList<TaxInspector> arlTaxInspectors = new ArrayList<TaxInspector>();
		// TaxInspector object
		TaxInspector objTaxInspector;
		// TaxInspector attributes
		String stTaxInspectorID;
		String stFirstName;
		String stLastName;
		LocalDate ldBirthday;
		Float flCommission;
		Float flCommissionPercentage;
		Integer iCheatedTaxPayers;
		/*
		 * 1st STEP: Connect to SQLite database
		 */
		Connection cnDB = connectToSQLiteDB();
		try {
			Statement staSQLquery = cnDB.createStatement();
			/*
			 * 2nd STEP: Check if the table exists. Otherwise, drop and create it again
			 */
			boolean bDropTableFirst = false;
			createTableIfNotExists(staSQLquery, bDropTableFirst);
			/*
			 * 3rd STEP: For every item, print it
			 */
			// Select all tax inspectors
			String stSQLSelect = "SELECT ID, firstName, lastName, birthday, commission, commissionPercentage, cheatedTaxPayers FROM "
					+ OBJTABLE_NAME;
			// return all records to the result set
			ResultSet rsTaxInspector = staSQLquery.executeQuery(stSQLSelect);
			int iNumTaxInspector = 0;
			while (rsTaxInspector.next()) {
				iNumTaxInspector++;
				// Get every attribute of the current TaxInspector row into a variable
				stTaxInspectorID = rsTaxInspector.getString("ID");
				stFirstName = rsTaxInspector.getString("firstName");
				stLastName = rsTaxInspector.getString("lastName");
				ldBirthday = LocalDate.parse(rsTaxInspector.getString("birthday"),
						DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				flCommission = rsTaxInspector.getFloat("commission");
				flCommissionPercentage = rsTaxInspector.getFloat("commissionPercentage");
				iCheatedTaxPayers = rsTaxInspector.getInt("cheatedTaxPayers");

				// Create a TaxInspector object with those attributes
				objTaxInspector = new TaxInspector(stTaxInspectorID, stFirstName, stLastName, ldBirthday, flCommission,
						flCommissionPercentage, iCheatedTaxPayers);
				// Add TaxInspector to temporal ArrayList
				arlTaxInspectors.add(objTaxInspector);
			}
			if (iNumTaxInspector == 0) {
				System.out.println("No items found on table " + OBJTABLE_NAME);
			}
			// Then, close RS and St
			rsTaxInspector.close(); // close the ResultSet
			staSQLquery.close(); // close the statement

		} catch (SQLException sqle) {
			System.out.println("Something was wrong while reading the table " + OBJTABLE_NAME);
			sqle.printStackTrace(System.out);
		}
		closeSQLiteDB(cnDB); // Finally, close the connection to the SQLite DB

		return arlTaxInspectors;

	}

	/*
	 * Dump data from SQLite DB to MongoDB DB
	 */
	public static void dumpDataFromSQLiteToMongoDB() {
		// Step 0: declare attributes for every Tax Inspector (to dump from SQLite to
		// MongoDB)
		// TaxInspector attributes
		String stTaxInspectorID;
		String stFirstName;
		String stLastName;
		String ldBirthday;
		Float flCommission;
		Float flCommissionPercentage;
		Integer iCheatedTaxPayers;

		Document docTaxInspector;
		// 1st Step: Get Tax Inspectors from SQLite
		ArrayList<TaxInspector> arlTaxInspector = getTaxInspectorsFromSQLiteDB();

		// 2nd Step: Connect to MongoDB database
		MongoClient cnDB = connectToMongoDBDB();

		// 3rd Step: create the collection and insert data
		try {
			// Try to establish the connection to DB
			MongoDatabase mDB = cnDB.getDatabase(MONGODB_DB_NAME);
			// Create the collection if not exists into the given database
			createCollectionIfNotExists(mDB);

			// Loop through the ArrayList to get every attribute of the current Tax
			// Inspector
			for (TaxInspector currentTI : arlTaxInspector) {
				// Get every attribute for better comprehension
				stTaxInspectorID = currentTI.getTaxInspectorID();
				stFirstName = currentTI.getFirstName();
				stLastName = currentTI.getLastName();
				ldBirthday = currentTI.getBirthday().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")); // Get the
																										// correct
																										// format of
																										// date
				flCommission = currentTI.getCommission();
				flCommissionPercentage = currentTI.getCommissionPercentage();
				iCheatedTaxPayers = currentTI.getCheatedTaxPayers();

				// Commented you can find an option to add a List of Documents instead of adding commission and commission percentage as single values themselves. 
				//List<Document> arlCommission = Arrays.asList(new Document("commtotal", String.valueOf(flCommission)), new Document("commpercentage", String.valueOf(flCommissionPercentage)));
				// Create a Document to insert the data
				docTaxInspector = new Document("taxinspectorID", String.valueOf(stTaxInspectorID))
						.append("firstname", String.valueOf(stFirstName))
						.append("lastname", String.valueOf(stLastName))
						.append("birthday", String.valueOf(ldBirthday))
						.append("commission", String.valueOf(flCommission)) 
						.append("commpercentage", String.valueOf(flCommissionPercentage))
						//.append("commission", arlCommission)
						.append("cheatedtaxpayers", String.valueOf(iCheatedTaxPayers));
				
				// 4th Step: Insert Document into database
				mDB.getCollection(COLLECTION_NAME).insertOne(docTaxInspector);
				System.out.println(docTaxInspector + " inserted successfuly");
			}
		} catch (Exception exe) {
			System.out.println("Something went wrong!");
			exe.printStackTrace(System.out);
		}
		closeMongoDBDB(cnDB);

	}

}

package ui;

import java.util.ArrayList;

import prg.TaxInspector;
import prg.TaxInspectorManagerDB;
import utils.IOTools;

/**
 * =====================================================================
 * Program to manage TaxInspectors. Runnable main with UI.
 * 
 * @author Roldán Sanchis Martínez. Based and modified from Abelardo Mart�nez
 *         =====================================================================
 */
public class AppTaxInspectorManager {

	/**
	 * ---------------------------------------- GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */
	// Objects
	private static final String OBJSNAME = "tax inspectors";

	/**
	 * ---------------------------------------- MENU AND MAIN
	 * ----------------------------------------
	 */
	/*
	 * --------------- MENU ---------------
	 */

	/** Print options menu */
	public static int printMenu() {
		// Integer that represents the selected option
		int option;

		System.out.println("");
		/*
		 * First element is the menu title (String title), rest of elements are the
		 * options list (String ... options)
		 */
		option = IOTools.showMenu("*****\nMENU\n*****", // Title
				"Exit", 
				"Get " + OBJSNAME + " and commissions (to SQLite)",
				"List all " + OBJSNAME + " (from SQLite)", 
				"Delete all " + OBJSNAME + " (from SQLite)",
				"[optional] Dump data from SQLite to MongoDB",
				"[optional] List all " + OBJSNAME + " (from MongoDB)");
		return option;
	}

	/*
	 * ---------------------------------- MAIN ----------------------------------
	 */
	public static void main(String[] stArgs) {
		ArrayList<TaxInspector> arlTaxInspector;
		boolean bQuit = false;
		int iOption;

		while (!bQuit) {
			iOption = printMenu();
			switch (iOption) {
			case 0: // exit the program
				bQuit = true;
				System.out.println("====> Goodbye and may the Force be with you!");
				break;
			case 1: // Insert TaxInspectors into SQLite DB
				System.out.println("====== ADDING ITEMS TO SQLite DB...");
				arlTaxInspector = TaxInspectorManagerDB.getTaxInspectorListFromKeyboard();
				//Check if the ArrayList is empty to avoid executing unnecessary code
				if(!arlTaxInspector.isEmpty()) {
					TaxInspectorManagerDB.writeTaxInspectorToSQLiteDB_JDBC(arlTaxInspector);
					}
				else {
					System.out.println("No Tax Inspectors added.");
				}
				IOTools.pressAnyKeyToContinue();
				break;
			case 2: // List TaxInspectors from SQLite DB
				System.out.println("======> LISTING ITEMS FROM SQLite DB...");
				TaxInspectorManagerDB.printTaxInspectorFromSQLiteDB_JDBC();
				IOTools.pressAnyKeyToContinue();
				break;
			case 3: // Delete all TaxInspectors from SQLite DB
				System.out.println("======> DELETING DB ITEMS...");
				TaxInspectorManagerDB.deleteTaxInspectorFromSQLiteDB();;
				IOTools.pressAnyKeyToContinue();
				break;
			case 4: // Dump data from SQLite DB to MongoDB DB
				System.out.println("======> DUMPING DATA FROM SQLite TO MongoDB...");
				TaxInspectorManagerDB.dumpDataFromSQLiteToMongoDB();
				IOTools.pressAnyKeyToContinue();
				break;
			case 5: // List all Tax Inspectors from MongoDB DB
				System.out.println("======> LISTING TAX INSPECTORS (from MongoDB DB)... ");
				TaxInspectorManagerDB.printTaxInspectorFromMongoDBDB_JDBC();
				IOTools.pressAnyKeyToContinue();
				break;
			default:
				System.out.println("====> Select an option or press 0");
			}

		}
	}
}

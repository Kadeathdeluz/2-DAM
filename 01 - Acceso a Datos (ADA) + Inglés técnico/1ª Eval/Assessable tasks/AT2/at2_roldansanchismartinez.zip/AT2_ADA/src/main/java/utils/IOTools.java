package utils;


import java.time.*;
import java.time.format.*;
import java.util.*;

/**
 * =====================================================================================
 * Auxiliary class. Methods to control data input
 *
 * @author Abelardo Mart�nez. Based and modified from Emiliano and Laia M�ndez
 * @version 24.09
 * =====================================================================================
 */

public class IOTools {
	/**
	 * ----------------------------------------
	 * GLOBAL VARIABLES AND CONSTANTS
	 * ---------------------------------------- 
	 */	
	/* We can only use ONE Scanner. When you call sc.close() it closes your underlying stream, which is System.in
	 * Once you close System.in the only way to get it back is to restart your program
	 * We can pass the instance to every method or create this static global
     */
	public static Scanner scKeyboard = new Scanner(System.in);

	/**
	 * ----------------------------------------- 
	 * DATATYPE METHODS
	 * -----------------------------------------
	 */
	/**
	 * ----------------------------------------- 
	 * STRING
	 * -----------------------------------------
	 */
    /* --------------------------------------------------------------------------
	 * Displays a text and waits for other text on the keypad. (NO spaces)
	 * --------------------------------------------------------------------------
	 */
	public static String askString(String stQuestion) {
		System.out.print(stQuestion + ": ");
		// https://stackoverflow.com/questions/13102045/scanner-is-skipping-nextline-after-using-next-or-nextfoo
		return scKeyboard.next();
	}

	/* --------------------------------------------------------------------------
	 * Displays a text and waits for other text on the keypad. (spaces ALLOWED)
	 * --------------------------------------------------------------------------
	 */
	public static String askStringSpaces(String stQuestion) {
		// https://stackoverflow.com/questions/13102045/scanner-is-skipping-nextline-after-using-next-or-nextfoo
		scKeyboard.nextLine();
		System.out.print(stQuestion + ": ");
		return scKeyboard.nextLine();
	}
	
	/*
	 * --------------------------------------------------------------------------------------
	 * Displays a text and waits for other text on the keypad. (spaces ALLOWED, REQUIRED)
	 * --------------------------------------------------------------------------------------
	 */
	public static String askStringSpacesRequired(String stQuestion) {
		String stReply = "";
		while (stReply.isEmpty()) {
			scKeyboard.nextLine();
			System.out.print(stQuestion + ": ");
			stReply = scKeyboard.nextLine();
			//check if the string is empty
			if (stReply.isEmpty()) {
				System.out.println("Error: this field can't be empty. Try again.");
			}
		}
		return stReply;
	}

	/**
	 * ----------------------------------------- 
	 * DATE
	 * -----------------------------------------
	 */
	/* -----------------------------------------------------------------------------------------
	 * Displays a text and waits for a date by keyboard. (DEFAULT format yyyy/mm/dd)
	 * -----------------------------------------------------------------------------------------
	 */
	public static LocalDate askDate(String stQuestion) {
		boolean bIsValid = false;
		LocalDate ldtDate = null;
		do {
			String stValue = askString(stQuestion); // read the above method question
			try {
				ldtDate = LocalDate.parse(stValue, DateTimeFormatter.BASIC_ISO_DATE);
				bIsValid = true;
			} catch (DateTimeParseException nfe) {
				System.out.println("Error: " + stValue + " is not a valid date");
			}
		} while (!bIsValid);
		return ldtDate;
	}
	
	/* -----------------------------------------------------------------------------------------
	 * Displays a text and waits for a date by keyboard. (SPECIFIC user format)
	 * -----------------------------------------------------------------------------------------
	 */
	public static LocalDate askDate(String stQuestion, String stDateFormat) {
		boolean bIsValid = false;
		LocalDate ldtDate = null;
		do {
			String stValue = askString(stQuestion); // read the above method question
			try {
				ldtDate = LocalDate.parse(stValue, DateTimeFormatter.ofPattern(stDateFormat));
				bIsValid = true;
			} catch (DateTimeParseException nfe) {
				System.out.println("Error: " + stValue + " is not a valid date. Required format: " + stDateFormat);
			}
		} while (!bIsValid);
		return ldtDate;
	}

	/**
	 * ----------------------------------------- 
	 * DATETIME
	 * -----------------------------------------
	 */
	/* --------------------------------------------------------------------------------------------
	 * Displays a text and waits for a datetime by keyboard. (DEFAULT format yyyy/mm/dd hh:mm:ss)
	 * --------------------------------------------------------------------------------------------
	 */
	public static LocalDateTime askDateTime(String stQuestion) {
		boolean bIsValid = false;
		LocalDateTime ldtDate = null;
		do {
			String stValue = askString(stQuestion); // read the above method question
			try {
				ldtDate = LocalDateTime.parse(stValue, DateTimeFormatter.BASIC_ISO_DATE);
				bIsValid = true;
			} catch (DateTimeParseException nfe) {
				System.out.println("Error: " + stValue + " is not a valid date");
			}
		} while (!bIsValid);
		return ldtDate;
	}
	
	/* -----------------------------------------------------------------------------------------
	 * Displays a text and waits for a date by keyboard. (SPECIFIC user format)
	 * -----------------------------------------------------------------------------------------
	 */
	public static LocalDateTime askDateTime(String stQuestion, String stDateFormat) {
		boolean bIsValid = false;
		LocalDateTime ldtDate = null;
		do {
			String stValue = askString(stQuestion); // read the above method question
			try {
				ldtDate = LocalDateTime.parse(stValue, DateTimeFormatter.ofPattern(stDateFormat));
				bIsValid = true;
			} catch (DateTimeParseException nfe) {
				System.out.println("Error: " + stValue + " is not a valid date. Required format: " + stDateFormat);
			}
		} while (!bIsValid);
		return ldtDate;
	}
	
	/**
	 * ----------------------------------------- 
	 * INTEGER
	 * -----------------------------------------
	 */
	/*
	 * -----------------------------------------------------------------------------------------
	 * Displays a text and waits for an integer by keyboard.
	 * -----------------------------------------------------------------------------------------
	 */
	public static int askInt(String stQuestion) {
		boolean bRepeat = true;
		int iResult = -1;
		do {
			String stValue = askString(stQuestion); // read the above method question
			try {
				iResult = Integer.parseInt(stValue);
				bRepeat = false;
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid integer number");
			}
		} while (bRepeat);

		return iResult;
	}
	
	/*
	 * -----------------------------------------------------------------------------------------
	 * Displays a text and waits for an integer by keyboard between a minimum and a maximum.
	 * -----------------------------------------------------------------------------------------
	 */
	public static int askInt(String stQuestion, int iMin, int iMax) {
		boolean bRepeat = true;
		int iResult = -1;
		do {
			String stValue = askString(stQuestion); // read the above method question
			try {
				iResult = Integer.parseInt(stValue);
				bRepeat = (iResult < iMin) || (iResult > iMax);
				if (bRepeat) {
					System.out.println("Error: " + iResult + " out of range");
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid integer number");
			}
		} while (bRepeat);

		return iResult;
	}

	/**
	 * ----------------------------------------- 
	 * LONG
	 * -----------------------------------------
	 */
	/*
	 * -------------------------------------------------------------------------------------------
	 * Displays a text and waits for a long by keyboard.
	 * -------------------------------------------------------------------------------------------
	 */
	public static long askLong(String stQuestion) {
		boolean bRepeat = true;
		long lResult = -1;
		do {
			String stValue = askString(stQuestion);
			try {
				lResult = Long.parseLong(stValue);
				bRepeat = false;
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid long number");
			}
		} while (bRepeat);

		return lResult;
	}
	
	/*
	 * -------------------------------------------------------------------------------------------
	 * Displays a text and waits for a long by keyboard between a minimum and a maximum.
	 * -------------------------------------------------------------------------------------------
	 */
	public static long askLong(String stQuestion, long lMin, long lMax) {
		boolean bRepeat = true;
		long lResult = -1;
		do {
			String stValue = askString(stQuestion);
			try {
				lResult = Long.parseLong(stValue);
				bRepeat = (lResult < lMin) || (lResult > lMax);
				if (bRepeat) {
					System.out.println("Error: " + lResult + " out of range");
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid long number");
			}
		} while (bRepeat);

		return lResult;
	}
	
	/**
	 * ----------------------------------------- 
	 * DOUBLE
	 * -----------------------------------------
	 */
	/*
	 * -------------------------------------------------------------------------------------------
	 * Displays a text and waits for a double by keyboard.
	 * -------------------------------------------------------------------------------------------
	 */
	public static double askDouble(String stQuestion) {
		
		boolean bRepeat = true;
		double dResult = -1;
		do {
			String stValue = askString(stQuestion);
			try {
				dResult = Double.parseDouble(stValue);
				bRepeat = false;
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid double number");
			}
		} while (bRepeat);
		
		return dResult;
	}
	
	/*
	 * -------------------------------------------------------------------------------------------
	 * Displays a text and waits for a double by keyboard between a minimum and a maximum.
	 * -------------------------------------------------------------------------------------------
	 */
	public static double askDouble(String stQuestion, double dMin, double dMax) {
		boolean bRepeat = true;
		double dResult = -1;
		do {
			String stValue = askString(stQuestion);
			try {
				dResult = Double.parseDouble(stValue);
				bRepeat = (dResult < dMin) || (dResult > dMax);
				if (bRepeat) {
					System.out.println("Error: " + dResult + " out of range");
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid double number");
			}
		} while (bRepeat);

		return dResult;
	}

	/**
	 * ----------------------------------------- 
	 * FLOAT
	 * -----------------------------------------
	 */
	/*
	 * -------------------------------------------------------------------------------------------
	 * Displays a text and waits for a float by keyboard.
	 * -------------------------------------------------------------------------------------------
	 */
	public static float askFloat(String stQuestion) {
		boolean bRepeat = true;
		float fResult = -1;
		do {
			String stValue = askString(stQuestion);
			try {
				fResult = Float.parseFloat(stValue);
				bRepeat = false;
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid float number");
			}
		} while (bRepeat);

		return fResult;
	}
	
	/*
	 * -------------------------------------------------------------------------------------------
	 * Displays a text and waits for a float by keyboard between a minimum and a maximum.
	 * -------------------------------------------------------------------------------------------
	 */
	public static float askFloat(String stQuestion, float fMin, float fMax) {
		boolean bRepeat = true;
		float fResult = -1;
		do {
			String stValue = askString(stQuestion);
			try {
				fResult = Float.parseFloat(stValue);
				bRepeat = (fResult < fMin) || (fResult > fMax);
				if (bRepeat) {
					System.out.println("Error: " + fResult + " out of range");
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Error: " + stValue + " is not a valid float number");
			}
		} while (bRepeat);

		return fResult;
	}

	/**
	 * ----------------------------------------- 
	 * MENU METHODS
	 * -----------------------------------------
	 */
	/*
	 * -------------------------------------------------------------------------------------------
	 *  Displays a text and waits for a number from a list of options.
	 * -------------------------------------------------------------------------------------------
	 */
	public static int askInt(String stQuestion, int... iValids) {
		boolean bAsk = true;
		int iResult;
		do {
			iResult = askInt(stQuestion, iValids[0], iValids[iValids.length - 1]);
			bAsk = Arrays.binarySearch(iValids, iResult) < 0;
		} while (bAsk);

		return iResult;
	}

	/*
	 * -------------------------------------------------------------------------------------------
	 *  Displays a menu and waits for the user to choose an option.
	 * -------------------------------------------------------------------------------------------
	 */
	public static int showMenu(String stTitle, String... stOptions) {
		System.out.println();
		System.out.println(stTitle);
		System.out.println("========================================================================");
		int iResult;
		
		if ((stOptions == null) || (stOptions.length == 0)) {
			iResult = -1;
		} else {
			int iNumOptions = 0;
			for (int ii = 0; ii < stOptions.length; ii++) {
				if ((stOptions[ii] == null) || ("".equals(stOptions[ii].trim()))) {
					System.out.println();
				} else {
					System.out.println("  " + iNumOptions + ". " + stOptions[ii]);
					iNumOptions++;
				}
			}
			System.out.println("========================================================================");
			iResult = askInt("    Select an option", 0, iNumOptions-1);
			System.out.println();
		}
		return iResult;
	}
	
	/*
	 * -------------------------------------------------------------------------------------------
	 * Message showed after doing some action to allow the user to see the result in the console. 
	 * -------------------------------------------------------------------------------------------
	 */
	public static void pressAnyKeyToContinue() {
		System.out.println(""); // Just a separator
		System.out.println("Press any key to continue...");
		try {
			System.in.read();
		} catch (Exception exe) {
		}
	}
}

package prg;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * =====================================================================
 * Object TaxInspector. Class.
 * Represents a Tax Inspector.
 * @author Rold�n Sanchis Mart�nez.
 * =====================================================================
 */
public class TaxInspector {

	/*
	 * ------------------------- ATTRIBUTES -------------------------
	 */
	private String taxInspectorID;
	private String firstName;
	private String lastName;
	private LocalDate birthday;
	private Float commission;
	private Float commissionPercentage;
	private Integer cheatedTaxPayers;

	/*
	 * ------------------------- METHODS -------------------------
	 */

	/*
	 * Constructor with all fields
	 */
	public TaxInspector(String taxInspectorID, String firstName, String lastName, LocalDate birthday, Float commision, Float commissionPercentage,
			Integer cheatedTaxPayers) {
		this.setTaxInspectorID(taxInspectorID);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setBirthday(birthday);
		this.setCommission(commision);
		this.setCommissionPercentage(commissionPercentage);
		this.setCheatedPlayers(cheatedTaxPayers);
	}

	/*
	 * ------------------------- GETTERS -------------------------
	 */
	public Integer getCheatedTaxPayers() {
		return cheatedTaxPayers;
	}

	public Float getCommissionPercentage() {
		return commissionPercentage;
	}
	
	public Float getCommission() {
		return commission;
	}

	public LocalDate getBirthday() {
		return birthday;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getTaxInspectorID() {
		return taxInspectorID;
	}

	/*
	 * ------------------------- SETTERS -------------------------
	 */
	public void setCheatedPlayers(Integer cheatedTaxPayers) {
		this.cheatedTaxPayers = cheatedTaxPayers;
	}

	public void setCommissionPercentage(Float commissionPercentage) {
		this.commissionPercentage = commissionPercentage;
	}

	public void setCommission(Float commision) {
		this.commission = commision;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setTaxInspectorID(String taxInspectorID) {
		this.taxInspectorID = taxInspectorID;
	}

	/*
	 * ------------------------- FORMATTED TEXT -------------------------
	 */
	
	@Override
	/** Overrides the toString method to show a descriptive text of the object itself */
	public String toString() {
		return "TaxInspectorID= " + taxInspectorID + ", FirstName= " + firstName + ", LastName= " + lastName 
				+ ", BirthDay= " + birthday.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) //use the correct format to print the LocalDate and also to save it to XML
				+ ", Commision= " + commission + ", Commission %=" + commissionPercentage +  ", CheatedTaxPayers= " + cheatedTaxPayers;
	}
	
	/** A toString variation to print a TaxInspector into a CSV file */
	public String toStringCSV() {
		
		return taxInspectorID + ", " + firstName + ", " + lastName + ", " + birthday.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) //use the correct format to print the LocalDate and also to save it to CSV
		+ ", " + commission + ", " + commissionPercentage +  ", " + cheatedTaxPayers;
	}

}

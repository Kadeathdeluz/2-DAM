package prg;

import utils.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * =====================================================================
 * Object Tax Inspector. CRUD Operations
 * @author Rold�n Sanchis Mart�nez. Based and modified from Abelardo Mart�nez
 * =====================================================================
 */

public class TaxInspectorManager {

	/**
	 * ----------------------------------------
	 * GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */
	//Object
	static final String OBJNAME = "Taxinspector";
	static final String OBJXMLNAME = "Taxinspector";
	//File name constants. We assume that our files are located in the project folder under the "resources" folder
	static final String CSV_FILENAME = "resources/taxinspectors.csv";
	//Date Format
	static final String DATE_FORMAT = "dd/MM/yyyy";

	/**
	 * ----------------------------------------
	 * MANAGE Tax Inspectors
	 * ---------------------------------------- 
	 */
	/*
	 * ----------------------------------------
	 * INSERT
	 * ---------------------------------------- 
	 */
	
	/*
	 * Get tax inspectors list from keyboard. Checks if the ID already exists in the array.
	 */
	public static ArrayList<TaxInspector> getTaxInspectorListFromKeyboard() {

		ArrayList<TaxInspector> arlTaxInspectors = new ArrayList<TaxInspector>(); //array of TaxInspectors
		String taxInspectorID;
		String firstName;
		String lastName;
		LocalDate birthday;
		Float commission;
		Float commissionPercentage;
		Integer cheatedTaxPayers;
		/*
		 * 1st STEP: We're asking for items until zero is set as ID
		 */
		while (true) {
			// Ask for ID while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				taxInspectorID = IOTools.askString(OBJNAME + " ID (zero to exit)");
				for (TaxInspector taxInspector : arlTaxInspectors) {
					if (taxInspectorID.equals(taxInspector.getTaxInspectorID())) {
						bExists = true;
						System.out.println("====> ERROR: ID already exists");
					}
				}
			} while (bExists);

			if (taxInspectorID.equals("0"))
				break;
			
			firstName = IOTools.askStringSpaces(OBJNAME + " firstname");
			lastName = IOTools.askStringSpaces(OBJNAME + " lastname");
			birthday = IOTools.askDate(OBJNAME + " birthday",DATE_FORMAT);
			commission = IOTools.askFloat(OBJNAME + " commission");
			commissionPercentage = IOTools.askFloat(OBJNAME + " commission percentage", 0, 30);
			cheatedTaxPayers = IOTools.askInt(OBJNAME + " cheated tax payers");
			/*
			 * 2nd STEP: We create an object (TaxInspector) as soon as we have the right data of an item
			 */
			TaxInspector objTaxInspector = new TaxInspector(taxInspectorID, firstName, lastName, birthday,commission, commissionPercentage, cheatedTaxPayers);

			/*
			 * 3rd STEP: Add the item to the ArrayList
			 */
			arlTaxInspectors.add(objTaxInspector);
			System.out.println("====> Added: " + objTaxInspector.toString());
			System.out.println("");
		}
		/*
		 * 4th STEP: Return the ArrayList
		 */
		return arlTaxInspectors;
	}

	/*
	 * Creates a XML with all the items of the ArrayList
	 */
	public static void writeTaxInspectorsToXML_DOM (ArrayList<TaxInspector> arlTaxInspectors, String fileXML) {

		TaxInspector objTaxInspector;
		Element eNode, eSubNode;

		try {
			//https://mkyong.com/java/how-to-create-xml-file-in-java-dom/
			DocumentBuilderFactory dbfTaxInspector = DocumentBuilderFactory.newInstance();
			DocumentBuilder dbTaxInspector = dbfTaxInspector.newDocumentBuilder();

			/*
			 * 1st STEP: Create DOM structure
			 */
			//root elements
			Document docTaxInspectorXML = dbTaxInspector.newDocument();

			//"s" for the root element as it will be "<TaxInspectors> and its nodes will be <TaxInspector>
			Element eRoot = docTaxInspectorXML.createElement(OBJXMLNAME + "s");
			//First "child" is root
			docTaxInspectorXML.appendChild(eRoot);

			/*
			 * 2nd STEP: For every item, add a node
			 */
			//Use an iterator to iterate the ArrayList
			Iterator<TaxInspector> itTaxInspector = arlTaxInspectors.iterator();
			
			while (itTaxInspector.hasNext()) {
				objTaxInspector = (TaxInspector) (itTaxInspector.next());
				
				//TaxInspector (node) elements (subNodes)
				eNode = docTaxInspectorXML.createElement(OBJXMLNAME);
				eRoot.appendChild(eNode);

				//SubNode for TaxInspectorID
				eSubNode = docTaxInspectorXML.createElement("id");
				eNode.appendChild(eSubNode);
				// https://stackoverflow.com/questions/4105331/how-do-i-convert-from-int-to-string
				//createTextNode() creates a node that only contains text (like a comment) to stare the value of the attribute
				eSubNode.appendChild(docTaxInspectorXML.createTextNode(objTaxInspector.getTaxInspectorID()));
				
				//SubNode for FirstName
				eSubNode = docTaxInspectorXML.createElement("firstname");
				eNode.appendChild(eSubNode);
				eSubNode.appendChild(docTaxInspectorXML.createTextNode(objTaxInspector.getFirstName()));
				
				//SubNode for LastName
				eSubNode = docTaxInspectorXML.createElement("lastname");
				eNode.appendChild(eSubNode);
				eSubNode.appendChild(docTaxInspectorXML.createTextNode(objTaxInspector.getLastName()));
				
				//SubNode for Birthday
				eSubNode = docTaxInspectorXML.createElement("birthday");
				eNode.appendChild(eSubNode);
				String.valueOf(objTaxInspector.getBirthday());
				eSubNode.appendChild(docTaxInspectorXML.createTextNode(objTaxInspector.getBirthday().format(DateTimeFormatter.ofPattern(DATE_FORMAT))));
				
				//SubNode for Commission
				eSubNode = docTaxInspectorXML.createElement("commission");
				eNode.appendChild(eSubNode);
				//Attribute for Commission Percentage
				eSubNode.setAttribute("percentage", String.valueOf(objTaxInspector.getCommissionPercentage()));
				eSubNode.appendChild(docTaxInspectorXML.createTextNode(String.valueOf(objTaxInspector.getCommission())));
				
				//SubNode for CheatedPlayers
				eSubNode = docTaxInspectorXML.createElement("cheatedtaxpayers");
				eNode.appendChild(eSubNode);
				eSubNode.appendChild(docTaxInspectorXML.createTextNode(String.valueOf(objTaxInspector.getCheatedTaxPayers())));
				
			}
			/*
			 * 3rd STEP: Create XML file
			 */
			saveTaxInspectorsToXML (docTaxInspectorXML, fileXML);
		/*
		 * Do not forget to set the proper exception handling here
		 */
		} catch (ParserConfigurationException pce) {
			System.out.println("Problems while parsing the XML");
			pce.printStackTrace();
		}
	}
	
	/*
	 * Creates a CSV file with all the items of the ArrayList
	 * */
	public static void writeTaxInspectorsToCSV (ArrayList<TaxInspector> arlTaxInspectors) {
		TaxInspector objTaxInspector;
		
		try {
			/*
			 * 1st STEP: Create a buffer (file) to store the items
			 */
			BufferedWriter bwFile = new BufferedWriter(new FileWriter(CSV_FILENAME));
			
			/*
			 * 1st-and-a-half STEP: Write "headers"
			 */
			bwFile.write("TaxInspectorID, FirstName, LastName, BirthDay, Commision, Commission %, CheatedTaxPayers" + "\n");
			/*
			 * 2nd STEP: For every item, add a line to the buffer (file)
			 */
			Iterator<TaxInspector> itTaxInspector = arlTaxInspectors.iterator();
			while (itTaxInspector.hasNext()) {
				// add items to the file
				objTaxInspector = (TaxInspector) (itTaxInspector.next());
				// Second "toString" used (the on for CSV files)
				bwFile.write(objTaxInspector.toStringCSV() + "\n");
				System.out.println("====> Written: " + objTaxInspector.toString() + "\n      as: " + objTaxInspector.toStringCSV() + "\n");
			}
			System.out.print("====> The file was saved properly");
			bwFile.close();

		} catch (FileNotFoundException fnfe) {
			System.out.println("File not found");
		} catch (IOException ioe) {
			System.out.println("I/O Error");
		}
		
		
	}
	
	/*
	 * Write the content of the Document created from the ArrayList into an XML file with the right parameters
	 */
	public static void saveTaxInspectorsToXML (Document docTaxInspectorXML, String fileXML) {

		//Standard structure of Transformer with Factory
		try {
			TransformerFactory tfTaxInspector = TransformerFactory.newInstance();
			Transformer tfTaxInspectorXML = tfTaxInspector.newTransformer();
			tfTaxInspectorXML.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			tfTaxInspectorXML.setOutputProperty(OutputKeys.INDENT, "yes");
			tfTaxInspectorXML.setOutputProperty(OutputKeys.METHOD, "xml");
			tfTaxInspectorXML.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			tfTaxInspectorXML.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");

			DOMSource dsTaxInspectorDOM = new DOMSource(docTaxInspectorXML);

			StreamResult strTaxInspector = new StreamResult(new File(fileXML));
			tfTaxInspectorXML.transform(dsTaxInspectorDOM, strTaxInspector);

		/*
		 * Do not forget to set the proper exception handling here
		 */
		} catch (TransformerException tfe) {
			System.out.println("Problems while generating the XML");
			tfe.printStackTrace();
		}
	}
	
	/*
	 * ----------------------------------------
	 * PRINT
	 * ---------------------------------------- 
	 */
	/*
	 * Read the XML file using DOM and print every TaxInspector information
	 */
	public static void printTaxInspectorsFromXML_DOM(String fileXML) {
		
		try {

			// Get Document Builder
			DocumentBuilderFactory dbfTaxInspector = DocumentBuilderFactory.newInstance();
			DocumentBuilder dbTaxInspector = dbfTaxInspector.newDocumentBuilder();

			//Build Document
			Document docTaxInspectorXML = dbTaxInspector.parse(new File(fileXML));

			//Normalize the XML Structure
			docTaxInspectorXML.getDocumentElement().normalize();

			//Root node
			Element eRoot = docTaxInspectorXML.getDocumentElement();
			System.out.println(""); // Just a separator
			System.out.println("Listing: " + eRoot.getNodeName());

			//Get all TaxInspectors
			NodeList nListTaxInspector = docTaxInspectorXML.getElementsByTagName(OBJXMLNAME);
			System.out.println("====== FOUND: " + nListTaxInspector.getLength());

			//Loop through the node list of TaxInspectors (as nodes) and print every attribute (Element) of TaxInspector (also percentage as Attribute of Element commission)
			for (int ii = 0; ii < nListTaxInspector.getLength(); ii++) {
				Node nodeTaxInspector = nListTaxInspector.item(ii);
				System.out.println(""); // Just a separator
				if (nodeTaxInspector.getNodeType() == Node.ELEMENT_NODE) {
					// Print each item detail
					Element eElement = (Element) nodeTaxInspector;
					System.out.println(OBJNAME + " ID: " + eElement.getElementsByTagName("id").item(0).getTextContent());
					System.out.println(
							OBJNAME + " FirstName: " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
					System.out.println(
							OBJNAME + " LastName: " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
					System.out.println(
							OBJNAME + " Birthday: " + eElement.getElementsByTagName("birthday").item(0).getTextContent());
					
					//Get the Element Commission to get its content and attribute
					Element elemCommission = (Element) eElement.getElementsByTagName("commission").item(0);
					System.out.println(
							OBJNAME + " Commission: " + elemCommission.getTextContent());
					System.out.println(
							OBJNAME + " Commission %: " + elemCommission.getAttribute("percentage"));
					
					System.out.println(
							OBJNAME + " CheatedTaxPayers: " + eElement.getElementsByTagName("cheatedtaxpayers").item(0).getTextContent());
					
				}
			}
		/*
		 * Do not forget to set the proper exception handling here
		 */
		} catch (ParserConfigurationException pce) {
			System.out.println("Problems while parsing the XML");
			pce.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Problems while accessing the XML");
			System.out.println(ioe.getMessage());
		} catch (Exception exe) {
			System.out.println("Problems while accessing the XML");
			exe.printStackTrace();
		}
	}

	/*
	 * ----------------------------------------
	 * GENERATE HTML
	 * ---------------------------------------- 
	 */
	/*
	 * Generate an HTML from an XML using the proper XSL for pattern
	 */
	public static void writeTaxInspectorsFromXMLtoHTML_XSL(String fileXML, String fileHTML, String fileXSL) {

		try {
			Source stsTaxInspectorXML = new StreamSource(fileXML);
			Source stsTaxInspectorXSL = new StreamSource(fileXSL);
			FileWriter fwHTML = new FileWriter(fileHTML);
			StringWriter stwHTML = new StringWriter();

			TransformerFactory tfTaxInspector = TransformerFactory.newInstance();
			Transformer tfTaxInspectorXSL = tfTaxInspector.newTransformer(stsTaxInspectorXSL);
			tfTaxInspectorXSL.transform(stsTaxInspectorXML, new StreamResult(stwHTML));
			fwHTML.write(stwHTML.toString());
			fwHTML.close();
			
			System.out.println("");
			System.out.println("==> File " + fileHTML + " generated using " + fileXSL);
		/*
		 * Do not forget to set the proper exception handling here
		 */
		} catch (TransformerException tfe) {
			System.out.println("Problems while parsing the XML");
			System.out.println(tfe.getMessage());
		} catch (IOException ioe) {
			System.out.println("Problems while accessing the XML");
			System.out.println(ioe.getMessage());
		} catch (Exception exe) {
			exe.printStackTrace();
		}
	}

	/*
	 ----------------------------------------
	 * MODIFY XML
	 * ----------------------------------------
	 * */
	/*
	 * Patch to remove extra empty lines in the modified DOM structure
	 */
	public static void normalizeTaxInspectorsDOM (Document docTaxInspectorXML) {
		/*
		 * The Transformer may add many empty newlines in the output XSL option:
		 * Solution/Patch 2:
		 * https://stackoverflow.com/questions/12669686/how-to-remove-extra-empty-lines-
		 * from-xml-file
		 */
		int ii; //loop counter
		Node nodeTaxInspector;
		
		try {
			//Patch 2
			XPath xp = XPathFactory.newInstance().newXPath();
			NodeList nlTaxInspector = (NodeList) xp.evaluate("//text()[normalize-space(.)='']", docTaxInspectorXML,
					XPathConstants.NODESET);

			for (ii = 0; ii < nlTaxInspector.getLength(); ++ii) {
				nodeTaxInspector = nlTaxInspector.item(ii);
				nodeTaxInspector.getParentNode().removeChild(nodeTaxInspector);
			}

		/*
		 * Do not forget to set the proper exception handling here
		 */
		} catch (XPathExpressionException xpee) {
			System.out.println("Problems while removing extra empty lines from the XML");
			xpee.printStackTrace();
		}
	}
	
	/*
	 * Modifies the commission of a given Tax Inspector (given ID) into given XML file
	 * */
	public static void modifyTaxInspectorCommission(String strTaxInspectorID, String fileXML) {
		int ii; //loop counter
		String stNodeID;
		boolean bModified = false;
		Node nodeTaxInspector;
		Element eElement;

		try {

			// Get Document Builder
			DocumentBuilderFactory dbfTaxInspector = DocumentBuilderFactory.newInstance();
			DocumentBuilder dbTaxInspector = dbfTaxInspector.newDocumentBuilder();

			// Build Document
			Document docTaxInspectorXML = dbTaxInspector.parse(new File(fileXML));

			// Normalize the XML Structure
			docTaxInspectorXML.getDocumentElement().normalize();

			// Get all TaxInspectors (as a node list)
			NodeList nListTaxInspector = docTaxInspectorXML.getElementsByTagName(OBJXMLNAME);

			//Loop through the node list
			for (ii = 0; ii < nListTaxInspector.getLength(); ii++) {
				//Current node of node list
				nodeTaxInspector = nListTaxInspector.item(ii);
				
				System.out.println(""); // Just a separator
				
				if (nodeTaxInspector.getNodeType() == Node.ELEMENT_NODE) {
					// Print each item detail
					eElement = (Element) nodeTaxInspector;
					//ID of the node (Tax Inspector ID)
					stNodeID = eElement.getElementsByTagName("id").item(0).getTextContent();
					
					//Commission as Element (to access commission percentage as Attribute)
					Element elemCommission = (Element) eElement.getElementsByTagName("commission").item(0);
					
					//Only modify the correct Tax Inspector with given ID
					if (stNodeID.equals(strTaxInspectorID)) {
						//Ask IO for a new commission percentage (between 0 and 30)
						Float newCommissionPercentage = IOTools.askFloat("New commission percentage", 0, 30);
						//Set the attribute to the new percentage
						elemCommission.setAttribute("percentage", newCommissionPercentage.toString());
						System.out.println(OBJNAME + " ID: " + stNodeID + " modified commission percentage to " + newCommissionPercentage + " .");
						bModified = true;
					}
				}
			}

			if (bModified) {
				//Patch to remove extra empty lines in the modified DOM structure
				normalizeTaxInspectorsDOM (docTaxInspectorXML);
				//Overwrite XML file
				saveTaxInspectorsToXML(docTaxInspectorXML, fileXML);
			} else {
				System.out.println(OBJNAME + " ID: " + strTaxInspectorID + " NOT found.");
			}
		/*
		 * Do not forget to set the proper exception handling here
		 */
		} catch (ParserConfigurationException pce) {
			System.out.println("Problems while parsing the XML");
			pce.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Problems while accessing the XML");
			System.out.println(ioe.getMessage());
		} catch (Exception exe) {
			System.out.println("Another problems with the XML");
			exe.printStackTrace();
		}
		
	}

	/* Write the meanest TaxInspectors (200+ Cheated Tax Payers) to given XML file from CSV file */
	public static void writeMeanestInspectorsFromCSVToXML(String fileXML) {
		ArrayList<TaxInspector> arlTempInspectors = new ArrayList<TaxInspector>(); //Temporal ArrayList of TaxInspectors
		
		try {
			File fiFile = new File(CSV_FILENAME);
			BufferedReader brFile = new BufferedReader(new FileReader(fiFile));
			String stLine;
			//Just skip the first line
			brFile.readLine();
			while ((stLine = brFile.readLine()) != null) {
				//Instead of splitting with "," I split with ", " because I save the values as "elem1, elem2..." with spaces in between
				String [] taxInspectorValues = stLine.split(", "); //This is the current Tax Inspector
				int cheatedTaxPayers = Integer.parseInt(taxInspectorValues[6]);
				
				//Only save meanest Tax Inspectors (so only "create" the meanest to save them to XML)
				if(cheatedTaxPayers >= 200) {
					//This is one of the meanest Tax Inspector
					TaxInspector meanTaxInspector = new TaxInspector(
							taxInspectorValues[0],
							taxInspectorValues[1],
							taxInspectorValues[2],
							LocalDate.parse(taxInspectorValues[3],DateTimeFormatter.ofPattern(DATE_FORMAT)), //Need to format LocalDate to "DATE_FORMAT"
							Float.parseFloat(taxInspectorValues[4]),
							Float.parseFloat(taxInspectorValues[5]),
							cheatedTaxPayers);
					
					//Add it to a temporal ArrayList
					arlTempInspectors.add(meanTaxInspector);
				}
			}
			//Finally, if we have at least one mean Tax Inspector we write it to our XML despicables.xml
			if(!arlTempInspectors.isEmpty()) {
				writeTaxInspectorsToXML_DOM(arlTempInspectors, fileXML);
			}
			brFile.close();
		}

		catch (FileNotFoundException fnfe) {
			System.out.println("File not found");
		} catch (IOException ioe) {
			System.out.println("I/O Error");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

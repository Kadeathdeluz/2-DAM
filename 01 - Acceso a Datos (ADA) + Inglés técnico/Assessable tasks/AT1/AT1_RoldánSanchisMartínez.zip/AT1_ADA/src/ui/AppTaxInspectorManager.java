package ui;

import java.util.ArrayList;

import prg.TaxInspector;
import prg.TaxInspectorManager;
import utils.IOTools;

/**
 * =====================================================================
 * Application. Runnable main with UI.
 * 
 * @author Rold�n Sanchis Mart�nez. Based and modified from Abelardo Mart�nez
 *         =====================================================================
 */
public class AppTaxInspectorManager {

	/**
	 * ---------------------------------------- GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */
	// Objects
	private static final String OBJSNAME = "TaxInspector";

	// File name constants. We assume that our files are located in the project folder under the "resources" folder
	static final String CSV_FILENAME = "resources/taxinspectors.csv";
	static final String XML_FILENAME = "resources/taxinspectors.xml";
	static final String HTML_FILENAME = "resources/taxinspectors.html";
	static final String XSL_FILENAME = "resources/taxinspectors.xsl";
	/* Documents for meanest tax inspectors */
	static final String XML_DESPICABLES = "resources/despicables.xml";
	static final String XSL_DESPICABLES = "resources/despicables.xsl";
	static final String HTML_DESPICABLES = "resources/despicables.html";

	/**
	 * ---------------------------------------- MENU AND MAIN
	 * ----------------------------------------
	 */
	/*
	 * --------------- MENU ---------------
	 */

	/** Prints options menu */
	public static int printMenu() {
		// Integer that represents the selected option
		int option;

		System.out.println("");
		/*
		 * First element is the menu title (String title), rest of elements are the
		 * options list (String ... options)
		 */
		option = IOTools.showMenu("*****\nMENU\n*****", "Exit", "Get " + OBJSNAME + " and commissions (to CSV & XML)",
				"List all " + OBJSNAME + " stored (using DOM)", "Generate HTML with all " + OBJSNAME + " via XSL",
				"[optional] Modify the commission of a " + OBJSNAME,
				"[optional] Generate HTML with the meanest " + OBJSNAME + " via XSL");
		return option;
	}

	/*
	 * ---------------------------------- MAIN ----------------------------------
	 */
	public static void main(String[] stArgs) {
		ArrayList<TaxInspector> arlTaxInspector;
		boolean bQuit = false;
		int iOption;

		while (!bQuit) {
			iOption = printMenu();
			switch (iOption) {
			case 0: // exit the program
				bQuit = true;
				System.out.println("====> Goodbye and may the Force be with you!");
				break;
			case 1: // Insert TaxInspectors to XML file and CSV (using DOM)
				System.out.println("======> ADDING ITEMS TO FILE...");
				arlTaxInspector = TaxInspectorManager.getTaxInspectorListFromKeyboard();
				//Check if the ArrayList is empty to avoid executing unnecessary code
				if(!arlTaxInspector.isEmpty()) {
					TaxInspectorManager.writeTaxInspectorsToXML_DOM(arlTaxInspector, XML_FILENAME);
					TaxInspectorManager.writeTaxInspectorsToCSV(arlTaxInspector);
					}
				else {
					System.out.println("No Tax Inspectors added.");
				}
				IOTools.pressAnyKeyToContinue();
				break;
			case 2: // List TaxInspectors (using DOM)
				System.out.println("======> LISTING ITEMS FROM FILE...");
				TaxInspectorManager.printTaxInspectorsFromXML_DOM(XML_FILENAME);
				IOTools.pressAnyKeyToContinue();
				break;
			case 3: // Generate HTML from XML with XSL
				System.out.println("======> GENERATING HTML (via XSL) FROM FILE...");
				TaxInspectorManager.writeTaxInspectorsFromXMLtoHTML_XSL(XML_FILENAME, HTML_FILENAME, XSL_FILENAME);
				IOTools.pressAnyKeyToContinue();
				break;
			case 4: // Modify the commission of a Tax Inspector
				System.out.println("======> MODIFYING TAX INSPECTOR COMMISSION...");
				String taxInspectorID = IOTools.askString("Modify commission percentage of " + OBJSNAME + " with ID");
				TaxInspectorManager.modifyTaxInspectorCommission(taxInspectorID, XML_FILENAME);
				// TaxInspectorManager.printTaxInspectorsFromXML_DOM(); //<<- If you want to show them after modifying
				IOTools.pressAnyKeyToContinue();
				break;
			case 5: // Generate HTML with meanest Tax Inspectors (cheated tax payers >= 200) via XSL
				System.out.println("======> LISTING MEANEST TAX INSPECTORS... ");
				// Using the same method to write the meanest Tax Inspectors, just change files
				TaxInspectorManager.writeMeanestInspectorsFromCSVToXML(XML_DESPICABLES);
				TaxInspectorManager.writeTaxInspectorsFromXMLtoHTML_XSL(XML_DESPICABLES, HTML_DESPICABLES, XSL_DESPICABLES);
				IOTools.pressAnyKeyToContinue();
				break;
			default:
				System.out.println("====> Select an option or press 0");
			}

		}
	}
}

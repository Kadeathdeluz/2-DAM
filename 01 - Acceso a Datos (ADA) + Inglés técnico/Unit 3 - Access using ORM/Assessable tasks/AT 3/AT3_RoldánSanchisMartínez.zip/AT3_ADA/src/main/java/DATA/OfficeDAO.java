package DATA;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import DOMAIN.Office;
import DOMAIN.TaxInspector;
import UTIL.HibernateUtil;

/**
 * Data Access Object of Office Object.
 * @author Roldán Sanchis Martínez.
 * */
public class OfficeDAO {

	/**
	 * ----------------------------------------
	 * GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */	
	//Object name constant
	static final String OBJECTNAME = "Office";
	
	/*
	 * ------------------
	 * INSERT
	 * ------------------
	 */
	/* CREATE an Office in the database */
	public Office addOffice(String code, String city) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction
		Office objOffice = new Office(code, city, null);
		
		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			hibSession.persist(objOffice); //insert
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item added.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
		return objOffice;
	}

	/*
	 * ------------------
	 * SELECT
	 * ------------------
	 */
	/* READ all the Offices */
	public void listOffices() {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			//old createQuery method is deprecated, but still working in the latest version
			//https://www.roseindia.net/hibernate/hibernate5/hibernate-5-query-deprecated.shtml
			List<Office> lstOffice = hibSession.createQuery("FROM " + OBJECTNAME, Office.class).list();
			if (lstOffice.isEmpty())
				System.out.println("******** No items found");
			else
				System.out.println("\n***** Start listing ...\n");

			for (Iterator<Office> itOffice = lstOffice.iterator(); itOffice.hasNext();) {
				Office objOffice = (Office) itOffice.next();
				System.out.println(objOffice.toStringDB()); // Use the toString version to show data from DB
				
			}
			txDB.commit(); //ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}
	
	/* Get Office by code */
	public Office getOfficeByCode(String code) {

		Office objOffice = null;
		Session hibSession = HibernateUtil.SFACTORY.openSession(); // open Hibernate session factory

		try {
			objOffice = hibSession.get(Office.class, code);
			
		} catch (HibernateException hbe) {
			hbe.printStackTrace();
		} finally {
			hibSession.close(); // close Hibernate session
		}
		return new Office(objOffice.getCode(), objOffice.getCity(), new HashSet<TaxInspector>(0));
	}

	/*
	 * ------------------
	 * UPDATE
	 * ------------------
	 */
	/* UPDATE an Office */
	public void updateOffice(String code, String city, Set<TaxInspector> taxinspectors) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			Office objOffice = (Office) hibSession.get(Office.class, code);
			objOffice.setCode(code);
			objOffice.setCity(city);
			objOffice.setTaxinspectors(taxinspectors);
			
			hibSession.merge(objOffice); //update
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item updated.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}
	
	/* UPDATE an Office (only the code) */
	public boolean updateOffice(String oldCode, String newCode) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			String sql = "UPDATE Office "
					+ "SET code = :newCode "
					+ "WHERE code = :oldCode";
			
			int rowsAffected = hibSession.createNativeQuery(sql, Office.class)
					.setParameter("newCode", newCode)
					.setParameter("oldCode", oldCode)
					.executeUpdate();
			
			txDB.commit(); //ends transaction
			if (rowsAffected > 0) {
				System.out.println(OBJECTNAME + " ***** Item updated.\n");
				return true;
			}
			else {
				System.out.println("Office not found. Please enter an existent one.");
			}
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
		return false;
	}

	/*
	 * ------------------
	 * DELETE
	 * ------------------
	 */
	/* DELETE an Office from the records */
	public void deleteOffice(String code) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			Office objOffice;
			if ((objOffice = (Office) hibSession.get(Office.class, code)) != null)
				hibSession.remove(objOffice); //delete
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item deleted.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

	/* DELETE all records */
	public void deleteAllItems() {
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			List<Office> lstOffice = hibSession.createQuery("FROM " + OBJECTNAME, Office.class).list();
			if (!lstOffice.isEmpty()) {
				int lstLen = lstOffice.size();// Just to properly print the info
				for (Iterator<Office> itOffice = lstOffice.iterator(); itOffice.hasNext();) {
					Office objOffice = (Office) itOffice.next();
					hibSession.remove(objOffice); //delete
				}
				System.out.println(OBJECTNAME + " ***** Item" + (lstLen > 1 ? "s" : "") + " deleted.\n"); // Elvis operator to properly print info
			}
			txDB.commit(); //ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}
	
}

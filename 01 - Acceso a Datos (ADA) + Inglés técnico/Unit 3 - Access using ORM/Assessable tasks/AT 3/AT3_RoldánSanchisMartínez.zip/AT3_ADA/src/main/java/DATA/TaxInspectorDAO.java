package DATA;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import DOMAIN.Office;
import DOMAIN.TaxInspector;
import DOMAIN.Taxpayer;
import UTIL.HibernateUtil;
import UTIL.UtilManager;

import org.hibernate.query.Query;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
/**
 * Data Access Object of TaxInspector Object.
 * @author Roldán Sanchis Martínez.
 * */
public class TaxInspectorDAO {
	/**
	 * ----------------------------------------
	 * GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */	
	//Object name constant
	static final String OBJECTNAME = "TaxInspector";
	
	/*
	 * ------------------
	 * INSERT
	 * ------------------
	 */
	/* CREATE a TaxInspector in the database */
	public TaxInspector addTaxInspector(String taxinsDNI, String firstName, String lastName, LocalDate birthday, 
			Float commision, Office office) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction
		TaxInspector objTaxInspector = new TaxInspector(taxinsDNI, firstName, lastName, birthday, 
				commision, office, new HashSet<Taxpayer>(0));
		
		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			hibSession.persist(objTaxInspector); //insert
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item added.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
		return objTaxInspector;
	}
	
	/* Overload of addTaxInspector: CREATE a TaxInspector in the database */
	public TaxInspector addTaxInspector(String taxinsDNI, String firstName, String lastName, LocalDate birthday, 
			Float commision, Office office, Set<Taxpayer> taxpayers) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction
		TaxInspector objTaxInspector = new TaxInspector(taxinsDNI, firstName, lastName, birthday, 
				commision, office, taxpayers);
		
		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			hibSession.persist(objTaxInspector); //insert
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item added.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
		return objTaxInspector;
	}

	/*
	 * ------------------
	 * SELECT
	 * ------------------
	 */
	/* READ all the TaxInspectors */
	public void listTaxInspectors() {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			//old createQuery method is deprecated, but still working in the latest version
			//https://www.roseindia.net/hibernate/hibernate5/hibernate-5-query-deprecated.shtml
			List<TaxInspector> lstTaxInspectors = hibSession.createQuery("FROM " + OBJECTNAME, TaxInspector.class).list();
			if (lstTaxInspectors.isEmpty())
				System.out.println("******** No items found");
			else
				System.out.println("\n***** Start listing ...\n");

			for (Iterator<TaxInspector> itTaxInspector = lstTaxInspectors.iterator(); itTaxInspector.hasNext();) {
				TaxInspector objTaxInspector = (TaxInspector) itTaxInspector.next();
				System.out.println(objTaxInspector.toStringDB()); // Use the toString version to show data from DB
				
			}
			txDB.commit(); //ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

	/* Get Taxpayer by nif  */
	public TaxInspector getTaxInspectorByDNI(String dni) {
		TaxInspector objTaxInspector = null;
		Session hibSession = HibernateUtil.SFACTORY.openSession(); // open Hibernate session factory

		try {
			objTaxInspector = hibSession.get(TaxInspector.class, dni);
			} catch (HibernateException hbe) {
			hbe.printStackTrace();
		} finally {
			hibSession.close(); // close Hibernate session
		}
		return objTaxInspector;
	}
	
	/** Get a list of TaxInspectors with a commission greater than the given one */
	public void listTaxInspectorsByCommission_HQL(Float commission) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); // open Hibernate session factory
		Transaction txDB = null; // database transaction
		List<TaxInspector> arlTaxInspectors = new ArrayList<TaxInspector>();
		
		try {
			txDB = hibSession.beginTransaction(); // starts transaction
			// 1. Create a CriteriaBuilder instance by calling the Session.getCriteriaBuilder() method.
			CriteriaBuilder crbCritBuilder = hibSession.getCriteriaBuilder();
			
			// 2. Create a query object by creating an instance of the CriteriaQuery interface.
			CriteriaQuery<TaxInspector> crqHQL1 = crbCritBuilder.createQuery(TaxInspector.class);
			
			// 3. Set the query Root by calling the from() method on the CriteriaQuery object to define a range variable in FROM clause.
			Root<TaxInspector> rootTaxInspector = crqHQL1.from(TaxInspector.class);
			
			// 4. Specify what the type of the query result will be by calling the select() method of the CriteriaQuery object.
			crqHQL1.select(rootTaxInspector).where(crbCritBuilder.gt(rootTaxInspector.get("commission"), commission));
			
			// 5. Prepare the query for execution by creating a org.hibernate.query.Query instance by calling the Session.createQuery() method, specifying the type of the query result.
			crqHQL1.orderBy(
					crbCritBuilder.asc(rootTaxInspector.get("lastName")),
					crbCritBuilder.asc(rootTaxInspector.get("firstName"))
					);
			Query<TaxInspector> qryHQL1 = hibSession.createQuery(crqHQL1);

			// 6. Execute the query by calling the getResultList() or getSingleResult() method on the org.hibernate.query.Query object.
			arlTaxInspectors = qryHQL1.getResultList();
			
			// Finally, print the result
			UtilManager.listTaxInspectorsFromList(arlTaxInspectors);

			txDB.commit(); // ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); // something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); // close Hibernate session
		}
		
	}

	/** Get a list of Taxpayers being investigated by a TaxInspector (by given dni) */
	public List<Taxpayer> getInvestigatedTaxpayersByInspector(String dni) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		List<Taxpayer> taxpayers = new ArrayList<Taxpayer>(); // List of taxpayers
		
		try {
			// Native SQL Query
			String sql = "SELECT t.nif, t.fullname, t.address, t.telephone "
					+ "FROM Taxfile tf "
					+ "INNER JOIN Taxpayer t "
					+ "ON tf.taxpaynif = t.nif "
					+ "WHERE tf.inspdni = :dni";
			
            // Get the list from the query
			NativeQuery<Taxpayer> query = hibSession.createNativeQuery(sql, Taxpayer.class);
			query.setParameter("dni", dni);
			
			taxpayers = query.getResultList(); 
            
        } catch(HibernateException hbe) {
        	hbe.printStackTrace();
        }finally {
        	hibSession.close(); // close Hibernate session
        }
		return taxpayers;
	}
	
	/** Get a list of Taxpayers being investigated by a TaxInspector (by given dni) */
	public void getInvestigatedTaxpayersByInspector_HQL(String dni) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); // open Hibernate session factory
		Transaction txDB = null; // database transaction
		List<Taxpayer> arlTaxpayers = new ArrayList<Taxpayer>();
		
		try {
			txDB = hibSession.beginTransaction(); // starts transaction
			// 1. Create a CriteriaBuilder instance by calling the Session.getCriteriaBuilder() method.
			CriteriaBuilder crbCritBuilder = hibSession.getCriteriaBuilder();
			
			// 2. Create a query object by creating an instance of the CriteriaQuery interface.
			CriteriaQuery<Taxpayer> crqHQL1 = crbCritBuilder.createQuery(Taxpayer.class);
			
			// 3. Set the query Root by calling the from() method on the CriteriaQuery object to define a range variable in FROM clause.
			Root<Taxpayer> rootTaxpayer = crqHQL1.from(Taxpayer.class);
			// Use a Left Join
			rootTaxpayer.fetch("taxinspectors", JoinType.LEFT);
			
			// 4. Get taxpayers from taxinspector by dni
			crqHQL1.where(crbCritBuilder.equal(rootTaxpayer.get("taxinspectors").get("dni"), dni));			
			
			// 5. Execute the query by calling the getResultList() or getSingleResult() method on the org.hibernate.query.Query object.
			arlTaxpayers = hibSession.createQuery(crqHQL1).getResultList();
			
			// Finally, print the result
			UtilManager.listTaxPayersFromList(arlTaxpayers);

			txDB.commit(); // ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); // something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); // close Hibernate session
		}
		
	}
	
	/*
	 * ------------------
	 * UPDATE
	 * ------------------
	 */
	/* UPDATE a TaxInspector */
	public void updateTaxInspector(String taxinsDNI, String firstName, String lastName, LocalDate birthday, 
			Float commision, Office office, Set<Taxpayer> taxpayers) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			TaxInspector objTaxInspector = (TaxInspector) hibSession.get(TaxInspector.class, taxinsDNI);
			objTaxInspector.setFirstName(firstName);
			objTaxInspector.setLastName(lastName);
			objTaxInspector.setBirthday(birthday);
			objTaxInspector.setCommission(commision);
			objTaxInspector.setOffice(office);
			objTaxInspector.setTaxpayers(taxpayers);
			
			hibSession.merge(objTaxInspector); //update
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item updated.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

	/*
	 * ------------------
	 * DELETE
	 * ------------------
	 */
	/* DELETE a TaxInspector from the records */
	public void deleteTaxInspector(String taxinsDNI) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			TaxInspector objTaxInspector;
			if ((objTaxInspector = (TaxInspector) hibSession.get(TaxInspector.class, taxinsDNI)) != null)
				hibSession.remove(objTaxInspector); //delete
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item deleted.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

	/* DELETE all records */
	public void deleteAllItems() {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			List<TaxInspector> lstTaxInspector = hibSession.createQuery("FROM " + OBJECTNAME, TaxInspector.class).list();
			if (!lstTaxInspector.isEmpty()) {
				int lstLen = lstTaxInspector.size(); // Just to properly print the info
				for (Iterator<TaxInspector> itTaxInspector = lstTaxInspector.iterator(); itTaxInspector.hasNext();) {
					TaxInspector objTaxInspector = (TaxInspector) itTaxInspector.next();
					hibSession.remove(objTaxInspector); //delete
				}
				System.out.println(OBJECTNAME + " ***** Item" + (lstLen > 1 ? "s" : "") + " deleted.\n"); // Elvis operator to properly print info
			}
			txDB.commit(); //ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}
}

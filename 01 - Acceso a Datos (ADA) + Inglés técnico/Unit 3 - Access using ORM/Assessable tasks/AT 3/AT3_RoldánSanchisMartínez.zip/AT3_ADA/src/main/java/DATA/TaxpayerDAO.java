package DATA;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import DOMAIN.TaxInspector;
import DOMAIN.Taxpayer;
import UTIL.HibernateUtil;

/**
 * Data Access Object of Taxpayer Object.
 * @author Roldán Sanchis Martínez.
 * */
public class TaxpayerDAO {

	/**
	 * ----------------------------------------
	 * GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */	
	//Object name constant
	static final String OBJECTNAME = "Taxpayer";
	
	/*
	 * ------------------
	 * INSERT
	 * ------------------
	 */
	/* CREATE a Taxpayer in the database */
	public Taxpayer addTaxpayer(String nif, String fullname, String address, String telephone) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction
		Taxpayer objTaxpayer = new Taxpayer(nif, fullname, address, telephone, new HashSet<TaxInspector>(0));
		
		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			hibSession.persist(objTaxpayer); //insert
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item added.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
		return objTaxpayer;
	}

	/*
	 * ------------------
	 * SELECT
	 * ------------------
	 */
	/* READ all the Taxpayers */
	public void listTaxpayers() {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			//old createQuery method is deprecated, but still working in the latest version
			//https://www.roseindia.net/hibernate/hibernate5/hibernate-5-query-deprecated.shtml
			List<Taxpayer> lstTaxpayer = hibSession.createQuery("FROM " + OBJECTNAME, Taxpayer.class).list();
			if (lstTaxpayer.isEmpty())
				System.out.println("******** No items found");
			else
				System.out.println("\n***** Start listing ...\n");

			for (Iterator<Taxpayer> itTaxpayer = lstTaxpayer.iterator(); itTaxpayer.hasNext();) {
				Taxpayer objTaxpayer = (Taxpayer) itTaxpayer.next();
				System.out.println(objTaxpayer.toStringDB()); // Use the toString version to show data from DB
				
			}
			txDB.commit(); //ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}
	
	/* Get Taxpayer by nif  */
	public Taxpayer getTaxpayerByNIF(String nif) {

		Taxpayer objTaxpayer;
		Session hibSession = HibernateUtil.SFACTORY.openSession(); // open Hibernate session factory

		try {
			objTaxpayer = hibSession.get(Taxpayer.class, nif);
			return objTaxpayer;
		} catch (HibernateException hbe) {
			hbe.printStackTrace();
			return null;
		} finally {
			hibSession.close(); // close Hibernate session
		}
	}
	
	/*
	 * ------------------
	 * UPDATE
	 * ------------------
	 */
	/* UPDATE a Taxpayer */
	public void updateTaxpayer(String nif, String fullname, String address, String telephone, Set<TaxInspector> taxinspectors) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			Taxpayer objTaxpayer = (Taxpayer) hibSession.get(Taxpayer.class, nif);
			objTaxpayer.setNif(nif);
			objTaxpayer.setFullname(fullname);
			objTaxpayer.setAddress(address);
			objTaxpayer.setTelephone(telephone);
			objTaxpayer.setTaxinspectors(taxinspectors);
			
			hibSession.merge(objTaxpayer); //update
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item updated.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

	/*
	 * ------------------
	 * DELETE
	 * ------------------
	 */
	/* DELETE a Taxpayer from the records */
	public void deleteTaxpayer(String nif) {
		
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			Taxpayer objTaxpayer;
			if ((objTaxpayer = (Taxpayer) hibSession.get(Taxpayer.class, nif)) != null)
				hibSession.remove(objTaxpayer); //delete
			txDB.commit(); //ends transaction
			System.out.println(OBJECTNAME + " ***** Item deleted.\n");
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

	/* DELETE all records */
	public void deleteAllItems() {
		Session hibSession = HibernateUtil.SFACTORY.openSession(); //open Hibernate session factory
		Transaction txDB = null; //database transaction

		try {
			txDB = hibSession.beginTransaction(); //starts transaction
			List<Taxpayer> lstTaxpayer = hibSession.createQuery("FROM " + OBJECTNAME, Taxpayer.class).list();
			if (!lstTaxpayer.isEmpty()) {
				int lstLen = lstTaxpayer.size(); // Just to properly print the info
				for (Iterator<Taxpayer> itTaxpayer = lstTaxpayer.iterator(); itTaxpayer.hasNext();) {
					Taxpayer objTaxpayer = (Taxpayer) itTaxpayer.next();
					hibSession.remove(objTaxpayer); //delete
				}
				System.out.println(OBJECTNAME + " ***** Item" + (lstLen > 1 ? "s" : "") + " deleted.\n"); // Elvis operator to properly print info
			}
			txDB.commit(); //ends transaction
		} catch (HibernateException hbe) {
			if (txDB != null)
				txDB.rollback(); //something went wrong, so rollback
			hbe.printStackTrace();
		} finally {
			hibSession.close(); //close Hibernate session
		}
	}

}

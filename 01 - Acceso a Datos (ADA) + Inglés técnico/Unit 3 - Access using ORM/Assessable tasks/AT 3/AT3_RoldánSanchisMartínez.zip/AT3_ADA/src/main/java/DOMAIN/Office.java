package DOMAIN;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/**
 * =====================================================================
 * Object Office. Class.
 * Represents an Office assigned to 1 or many TaxInspectors.
 * @author Roldán Sanchis Martínez.
 * =====================================================================
 */
@Entity
@Table(name = "Office", catalog = "ADAU3DBTaxinspectors")
public class Office implements java.io.Serializable {

	/*
	 * ------------------------------------------
	 * ATTRIBUTES
	 * ------------------------------------------
	 */
	
	private static final long serialVersionUID = 1L;
	private static final String OBJNAME = "Office";
	
	private String code;
	private String city;
	private Set<TaxInspector> taxinspectors = new HashSet<TaxInspector>(0);
	
	/*
	 * ------------------------- METHODS -------------------------
	 */
	
	/** Empty constructor */
	public Office() {
	}
	
	/*
	 * Constructor with primary key
	 */
	public Office(String code) {
		this.code = code;
	}
	
	/*
	 * Constructor with all fields
	 */
	public Office(String code, String city, Set<TaxInspector> taxinspectors) {
		this.code = code;
		this.city = city;
		this.taxinspectors = taxinspectors;
	}
	
	/*
	 * ------------------------- GETTERS -------------------------
	 */
	@Id
	@Column(name = "code", unique = true, updatable = true, nullable = false, length = 5)
	public String getCode() {
		return this.code;
	}

	@Column(name = "city")
	public String getCity() {
		return this.city;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "office")
	public Set<TaxInspector> getTaxinspectors() {
		return this.taxinspectors;
	}
	
	/*
	 * ------------------------- SETTERS -------------------------
	 */
	
	public void setCode(String code) {
		this.code = code;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setTaxinspectors(Set<TaxInspector> taxinspectors) {
		this.taxinspectors = taxinspectors;
	}
	
	/*
	 * ------------------------- FORMATTED TEXT -------------------------
	 */
	
	@Override
	/** Overrides the toString method to show a descriptive text of the object itself */
	public String toString() {
		return "Office Code= " + code + ", City= " + city + ", TaxInspectors(Set)= " + taxinspectors.toString();
	}
	
	/** Version of the toString method to show a descriptive text of the object from DB */
	public String toStringDB() {
		String text = OBJNAME + " Code: " + code + " | " 
				+ OBJNAME + " City: " + city;
		if(this.taxinspectors != null)
		for (Iterator<TaxInspector> itTaxInspector = taxinspectors.iterator(); itTaxInspector.hasNext();) {
			TaxInspector taxInspector  = (TaxInspector) itTaxInspector.next();
			text += "\nInspector DNI(associated): " + taxInspector.getDni();
		}
		return text;
	}

}

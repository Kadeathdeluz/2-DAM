package DOMAIN;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * =====================================================================
 * Object TaxInspector. Class.
 * Represents a Tax Inspector.
 * @author Roldán Sanchis Martínez.
 * =====================================================================
 */
@Entity
@Table(name = "Inspector", catalog = "ADAU3DBTaxinspectors")
public class TaxInspector implements java.io.Serializable{

	/*
	 * ------------------------- ATTRIBUTES -------------------------
	 */
	private static final String  OBJNAME = "TaxInspector";
	private static final long serialVersionUID = 1L;
	
	private String dni;
	private String firstName;
	private String lastName;
	private LocalDate birthday;
	private Float commission;
	private Office office;
	private Set<Taxpayer> taxpayers = new HashSet<Taxpayer>(0);

	/*
	 * ------------------------- METHODS -------------------------
	 */

	/* Empty constructor */
	public TaxInspector() {		
	}
	
	/* Constructor with primary key */
	public TaxInspector(String dni) {
		this.dni = dni;
	}
	
	/*
	 * Constructor with all fields
	 */
	public TaxInspector(String dni, String firstName, String lastName, LocalDate birthday, 
			Float commision, Office office, Set<Taxpayer> taxpayers) {
		this.setDni(dni);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setBirthday(birthday);
		this.setCommission(commision);
		this.office = office;
		this.taxpayers = taxpayers;
	}

	/*
	 * ------------------------- GETTERS -------------------------
	 */
	@Id
	@Column(name = "dni", unique = true, nullable = false, length = 9)
	public String getDni() {
		return this.dni;
	}
	
	@Column(name = "firstname")
	public String getFirstName() {
		return this.firstName;
	}
	
	@Column(name = "lastname")
	public String getLastName() {
		return this.lastName;
	}

	@Column(name = "birthday")
	public LocalDate getBirthday() {
		return this.birthday;
	}

	@Column(name = "commission")
	public Float getCommission() {
		return this.commission;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "code")
	public Office getOffice() {
		return this.office;
	}
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(
			name = "Taxfile", 
			catalog = "ADAU3DBTaxinspectors", 
			joinColumns = {
					@JoinColumn(name = "inspdni", nullable = true, updatable = true)}, 
			inverseJoinColumns = {
					@JoinColumn(name = "taxpaynif", nullable = false, updatable = false)}
			)
	public Set<Taxpayer> getTaxpayers() {
		return this.taxpayers;
	}

	/*
	 * ------------------------- SETTERS -------------------------
	 */


	public void setCommission(Float commision) {
		this.commission = commision;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}
	
	public void setOffice(Office office) {
		this.office = office;
	}

	public void setTaxpayers(Set<Taxpayer> taxpayers) {
		this.taxpayers = taxpayers;
	}

	/*
	 * ------------------------- FORMATTED TEXT -------------------------
	 */
	
	@Override
	/** Overrides the toString method to show a descriptive text of the object itself */
	public String toString() {
		return "TaxInspector DNI= " + dni + ", FirstName= " + firstName + ", LastName= " + lastName 
				+ ", BirthDay= " + birthday.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) //use the correct format to print the LocalDate and also to save it to XML
				+  ", Commission(%)=" + commission;
	}
	
	/** Version of the toString method to show a descriptive text of the object from DB */
	public String toStringDB() {
		String text = OBJNAME + " DNI: " + dni + " | " 
				+ OBJNAME + " FirstName: " + firstName + " | " 
				+ OBJNAME + " LastName: " + lastName + " | "
				+ OBJNAME + " BirthDay: " + birthday.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " | " //use the correct format to print the LocalDate and also to save it to XML
				+ OBJNAME + " Commission(%): " + commission
				+ OBJNAME + " Office: " + office.getCode();
		if(taxpayers != null)
		for (Iterator<Taxpayer> itTaxpayer = this.taxpayers.iterator(); itTaxpayer.hasNext();) {
			Taxpayer taxpayer  = (Taxpayer) itTaxpayer.next();
			text += "\nTaxpayer (investigated): " + taxpayer.getNif() + ", " + taxpayer.getFullname();
		}
		return text;
	}

}

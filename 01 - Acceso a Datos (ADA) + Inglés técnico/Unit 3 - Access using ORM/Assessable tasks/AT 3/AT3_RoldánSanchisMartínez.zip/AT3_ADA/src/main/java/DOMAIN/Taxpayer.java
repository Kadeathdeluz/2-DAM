package DOMAIN;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

/**
 * ===================================================================== 
 * Object Taxpayer. Class.
 * Represents a Tax Payer.
 * @author Roldán Sanchis Martínez.
 *         =====================================================================
 */
@Entity
@Table(name = "Taxpayer", catalog = "ADAU3DBTaxinspectors")
public class Taxpayer implements java.io.Serializable {
	/*
	 * ------------------------------------------ ATTRIBUTES
	 * ------------------------------------------
	 */
	private static final String  OBJNAME = "Taxpayer";
	private static final long serialVersionUID = 1L;
	
	private String nif;
	private String fullname;
	private String address;
	private String telephone;
	private Set<TaxInspector> taxinspectors = new HashSet<TaxInspector>(0);

	/*
	 * ------------------------- METHODS -------------------------
	 */

	/* Empty constructor */
	public Taxpayer() {
	}

	/* Constructor with key */
	public Taxpayer(String nif) {
		this.nif = nif;
	}

	/* Constructor with all fields */
	public Taxpayer(String nif, String fullname, String address, String telephone, Set<TaxInspector> taxinspectors) {
		this.nif = nif;
		this.fullname = fullname;
		this.address = address;
		this.telephone = telephone;
		this.taxinspectors = taxinspectors;
	}
	
	/*
	 * ------------------------- GETTERS -------------------------
	 */
	@Id
	@Column(name = "nif", unique = true, nullable = false, length = 9)
	public String getNif() {
		return this.nif;
	}

	@Column(name = "fullname")
	public String getFullname() {
		return this.fullname;
	}

	@Column(name = "address")
	public String getAddress() {
		return this.address;
	}

	@Column(name = "telephone", length = 12)
	public String getTelephone() {
		return this.telephone;
	}

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(
			name = "Taxfile", 
			catalog = "ADAU3DBTaxinspectors", 
			joinColumns = {
					@JoinColumn(name = "taxpaynif", nullable = true, updatable = true)}, 
			inverseJoinColumns = {
					@JoinColumn(name = "inspdni", nullable = false, updatable = false)}
			)
	public Set<TaxInspector> getTaxinspectors() {
		return this.taxinspectors;
	}

	/*
	 * ------------------------- SETTERS -------------------------
	 */
	
	public void setNif(String nif) {
		this.nif = nif;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public void setTaxinspectors(Set<TaxInspector> taxinspectors) {
		this.taxinspectors = taxinspectors;
	}

	/*
	 * ------------------------- FORMATTED TEXT -------------------------
	 */
	
	@Override
	/** Overrides the toString method to show a descriptive text of the object itself */
	public String toString() {
		return OBJNAME + " NIF= " + nif + ", FullName= " + fullname + ", Address= " + address
				+  ", Telephone=" + telephone + ", TaxInspectors(Set)= " + taxinspectors.toString();
	}
	
	/** Version of the toString method to show a descriptive text of the object from DB */
	public String toStringDB() {
		String text = OBJNAME + " NIF: " + nif + " | " 
				+ OBJNAME + " FullName: " + fullname + " | " 
				+ OBJNAME + " Address: " + address + " | "
				+ OBJNAME + " Telephone: " + telephone;
		if(this.taxinspectors != null)
		for (Iterator<TaxInspector> itTaxInspector = taxinspectors.iterator(); itTaxInspector.hasNext();) {
			TaxInspector taxInspector  = (TaxInspector) itTaxInspector.next();
			text += "\nTaxInspector DNI(investigated by): " + taxInspector.getDni();
		}
		return text;
	}
}

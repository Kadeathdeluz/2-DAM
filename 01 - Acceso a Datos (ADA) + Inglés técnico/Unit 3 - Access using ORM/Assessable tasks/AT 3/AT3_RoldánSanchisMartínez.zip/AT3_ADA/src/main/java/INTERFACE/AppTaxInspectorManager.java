package INTERFACE;

import java.time.LocalDate;
import java.util.HashSet;

import DATA.OfficeDAO;
import DATA.TaxInspectorDAO;
import DATA.TaxpayerDAO;
import DOMAIN.Office;
import DOMAIN.TaxInspector;
import DOMAIN.Taxpayer;
import UTIL.HibernateUtil;
import UTIL.IOTools;
import UTIL.UtilManager;

/**
 * ===================================================================== Program
 * to manage TaxInspectors, Offices and Taxpayers. Runnable main with UI.
 * 
 * @author Roldán Sanchis Martínez. Based and modified from Abelardo Martínez
 *         =====================================================================
 */
public class AppTaxInspectorManager {

	/**
	 * ---------------------------------------- GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */
	// Text constants
	private static final String INSP = "tax inspector";
	private static final String PAY = "taxpayer";
	private static final String OFFI = "office";

	// Create DAO objects to perform CRUD operations
	private static OfficeDAO objOfficeDAO = new OfficeDAO();
	private static TaxInspectorDAO objTaxInspectorDAO = new TaxInspectorDAO();
	private static TaxpayerDAO objTaxpayerDAO = new TaxpayerDAO();

	/**
	 * ---------------------------------------- MENU AND MAIN
	 * ----------------------------------------
	 */
	/*
	 * --------------- MENU ---------------
	 */

	/** Print options menu */
	public static int printMenu() {
		// Integer that represents the selected option
		int option;

		System.out.println("");
		/*
		 * First element is the menu title (String title), rest of elements are the
		 * options list (String ... options)
		 */
		option = IOTools.showMenu("*****\nMENU\n*****", // Title
				"Exit", "Insert & List " + OFFI + "s", "Insert & List " + PAY + "s", "Insert & List " + INSP + "s",
				"List " + PAY + "s under investigation (by " + INSP + ")", "Update " + OFFI, "Delete " + PAY + "s",
				"Delete " + INSP + "s", "[Optional] Find " + INSP + "s", "[Optional] Find " + PAY + "s",
				"[Additional] ⚡QUICK TEST⚡ WARNING: This will delete all the DB records");
		return option;
	}

	/*
	 * ---------------------------------- MAIN ----------------------------------
	 */
	public static void main(String[] stArgs) {

		boolean bQuit = false;
		int iOption;

		while (!bQuit) {
			iOption = printMenu();
			switch (iOption) {
			case 0: // exit the program
				bQuit = true;
				//Close Hibernate session
				HibernateUtil.shutdownSessionFactory();
				System.out.println("====> Goodbye and may the Force be with you!");
				break;
			case 1: // Insert & List offices
				UtilManager.insertAndListOffices(objOfficeDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 2: // Insert & List taxpayers
				UtilManager.insertAndListTaxPayers(objTaxpayerDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 3: // Insert & List tax inspectors
				UtilManager.insertAndListTaxInspectors(objTaxInspectorDAO, objOfficeDAO, objTaxpayerDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 4: // List taxpayers under investigation (by tax inspector)
				UtilManager.listTaxpayersByTaxInspector(objTaxInspectorDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 5: // Update office by Code
				UtilManager.updateOffice(objOfficeDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 6: // Delete taxpayers by NIF
				UtilManager.deleteTaxpayersByNif(objTaxpayerDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 7: // Delete tax inspectors by DNI
				UtilManager.deleteTaxInspectorsByDni(objTaxInspectorDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 8: // [Optional] Find tax inspectors
				UtilManager.findTaxInspectorsByCommission(objTaxInspectorDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 9: // [Optional] Find taxpayers
				UtilManager.findTaxpayersUnderInvestigationByDNI(objTaxInspectorDAO);
				IOTools.pressAnyKeyToContinue();
				break;
			case 10: // TEST
				test();
				IOTools.pressAnyKeyToContinue();
				break;
			default:
				System.out.println("====> Select an option or press 0");
			}

		}
		
	}

	/* Test that creates & updates several objects, and finally clears the DB */
	public static void test() {

		/* ------------------------- CREATE DAOs ------------------------- */
		// Create DAO to test CRUD operations
		OfficeDAO objOfficeDAO = new OfficeDAO();
		TaxInspectorDAO objTaxInspectorDAO = new TaxInspectorDAO();
		TaxpayerDAO objTaxpayerDAO = new TaxpayerDAO();

		/* ------------------------- CREATE OBJs ------------------------- */
		// Offices before Inspectors
		Office ofi1 = objOfficeDAO.addOffice("OFI01", "Valencia");
		Office ofi2 = objOfficeDAO.addOffice("OFI02", "Madrid");

		// Inspectors after Offices
		TaxInspector ins1 = objTaxInspectorDAO.addTaxInspector("12345678A", "Poco", "Yoyo", LocalDate.of(2024, 2, 1),
				20.5f, ofi1);
		TaxInspector ins2 = objTaxInspectorDAO.addTaxInspector("87654321B", "Mucho", "JOJO", LocalDate.of(2024, 4, 2),
				10.55f, ofi2);
		TaxInspector ins3 = objTaxInspectorDAO.addTaxInspector("11223344Z", "Rayo", "McKing", LocalDate.of(2024, 6, 3),
				23.75f, ofi1);

		// Finally, Taxpayers
		Taxpayer pay1 = objTaxpayerDAO.addTaxpayer("12312312F", "Perico de las Pelotas", "C/ Papaudo Poulos 5","+34656656656");
		Taxpayer pay2 = objTaxpayerDAO.addTaxpayer("32132132H", "Luke Caminacielos", "Colonia Polis Massa",
				"123456789012");
		Taxpayer pay3 = objTaxpayerDAO.addTaxpayer("00000001X", "Origen, la Semilla", "C/ El Origen", "+34000000001");

		/* ------------------------- CREATE SETS ------------------------- */
		// Inspectors per Office 1
		HashSet<TaxInspector> hsetInspectors1 = new HashSet<TaxInspector>();
		hsetInspectors1.add(ins1);
		hsetInspectors1.add(ins3);

		// Taxpayers per Inspector
		HashSet<Taxpayer> hsetTaxpayers = new HashSet<Taxpayer>();
		hsetTaxpayers.add(pay1);
		hsetTaxpayers.add(pay2);
		hsetTaxpayers.add(pay3);
		/* ------------------------- UPADATE OBJs with SETS ------------------------- */

		// Update TaxInspectors
		objTaxInspectorDAO.updateTaxInspector(ins2.getDni(), ins2.getFirstName(), ins2.getLastName(),
				ins2.getBirthday(), ins2.getCommission(), ins2.getOffice(), hsetTaxpayers);

		/* ------------------------- LIST OBJs ------------------------- */
		// Finally list all items
		objOfficeDAO.listOffices();
		objTaxInspectorDAO.listTaxInspectors();
		objTaxpayerDAO.listTaxpayers();

		System.out.println(); // Before delete, add "\n" <- Visual improve

		/* ------------------------- LIST OBJs ------------------------- */
		// Delete all (first Payers, then Inspectors, finally Offices)
		objTaxpayerDAO.deleteAllItems();
		objTaxInspectorDAO.deleteAllItems();
		objOfficeDAO.deleteAllItems();

		// Finally list all items to check that they are deleted
		objOfficeDAO.listOffices();
		objTaxInspectorDAO.listTaxInspectors();
		objTaxpayerDAO.listTaxpayers();

		// Close Hibernate session
		HibernateUtil.shutdownSessionFactory();
		System.out.println("\nDone!");
		System.exit(0); // Once the Factory is closed, end the program
	}
}

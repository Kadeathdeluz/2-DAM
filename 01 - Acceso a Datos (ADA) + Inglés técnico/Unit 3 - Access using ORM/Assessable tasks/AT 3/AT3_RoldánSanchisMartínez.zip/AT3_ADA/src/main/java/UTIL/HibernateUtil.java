package UTIL;

import java.util.logging.Level;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * =====================================================================
 * Class to manage Hibernate session
 * @author Abelardo Martínez. Based and modified from Sergio Badal
 * =====================================================================
 */

public class HibernateUtil {
	
	/**
	 * ----------------------------------------
	 * GLOBAL CONSTANTS AND VARIABLES
	 * ----------------------------------------
	 */	
	//Persistent session
	public static final SessionFactory SFACTORY = buildSessionFactory();

	/*
	 * ----------------------
	 * SESSION MANAGEMENT
	 * ----------------------
	 */
	/*
	 * Create new hibernate session
	 */
	private static SessionFactory buildSessionFactory() {
		java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.OFF);
		try {
			// Create the SessionFactory from hibernate.cfg.xml
			return new Configuration().configure().buildSessionFactory();
		} catch (Throwable sfe) {
			// Make sure you log the exception, as it might be swallowed
			System.err.println("SessionFactory creation failed." + sfe);
			throw new ExceptionInInitializerError(sfe);
		}
	}

	/*
	 * Close hibernate session
	 */
	public static void shutdownSessionFactory() {
		// Close caches and connection pools
		getSessionFactory().close();
	}
	
	/*
	 * Get method to obtain the session
	 */
	public static SessionFactory getSessionFactory() {
		return SFACTORY;
	}

}
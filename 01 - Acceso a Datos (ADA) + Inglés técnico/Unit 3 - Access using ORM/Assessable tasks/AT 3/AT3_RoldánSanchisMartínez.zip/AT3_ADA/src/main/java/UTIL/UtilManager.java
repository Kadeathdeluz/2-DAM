package UTIL;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import DATA.OfficeDAO;
import DATA.TaxInspectorDAO;
import DATA.TaxpayerDAO;
import DOMAIN.Office;
import DOMAIN.TaxInspector;
import DOMAIN.Taxpayer;

public class UtilManager {

	/** INSERT AND LIST */
	/**
	 * Get Offices list from keyboard, insert it into DB and list all Offices.
	 */
	public static void insertAndListOffices(OfficeDAO objOfficeDAO) {

		ArrayList<Office> arlOffices = new ArrayList<Office>(); // array of Offices
		
		// Office attributes
		String code;
		String city;

		/*
		 * 1st STEP: We're asking for items until zero is set as code
		 */
		while (true) {
			// Ask for code while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				code = IOTools.askString("Enter Office CODE (zero to exit)");
				for (Office office : arlOffices) {
					if (code.equals(office.getCode())) {
						bExists = true;
						System.out.println("====> ERROR: CODE already exists");
					}
				}
			} while (bExists);

			if (code.equals("0"))
				break;

			city = IOTools.askStringSpaces("city");
			/*
			 * 2nd STEP: We create an object as soon as we have the right
			 * data of an item
			 */
			Office objOffice = new Office(code, city, new HashSet<TaxInspector>(0));

			/*
			 * 3rd STEP: Add the item to the ArrayList
			 */
			arlOffices.add(objOffice);
			System.out.println("====> Added: " + objOffice.toString());
			System.out.println("");
		}

		if(!arlOffices.isEmpty()) {
			// Insert offices into BD
			for (Office office : arlOffices) {
				objOfficeDAO.addOffice(office.getCode(), office.getCity());
			}
		}

		// Finally, list the offices
		objOfficeDAO.listOffices();
	}
	
	/**
	 * Get Taxpayers list from keyboard, insert it into DB and list all Taxpayers.
	 */
	public static void insertAndListTaxPayers(TaxpayerDAO objTaxpayerDAO) {
		
		ArrayList<Taxpayer> arlTaxpayers = new ArrayList<Taxpayer>(); // array of Taxpayers
		
		// Taxpayer attributes
		String nif;
		String fullname;
		String address;
		String telephone;
		
		/*
		 * 1st STEP: We're asking for items until zero is set as nif
		 */
		while (true) {
			// Ask for nif while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				nif = IOTools.askString("Enter Taxpayer NIF (zero to exit)");
				for (Taxpayer taxpayer : arlTaxpayers) {
					if (nif.equals(taxpayer.getNif())) {
						bExists = true;
						System.out.println("====> ERROR: NIF already exists");
					}
				}
			} while (bExists);
			
			if (nif.equals("0"))
				break;
			
			fullname = IOTools.askStringSpaces("fullname");
			address = IOTools.askStringSpaces("address");
			telephone = IOTools.askString("telephone");
			/*
			 * 2nd STEP: We create an object as soon as we have the right
			 * data of an item
			 */
			Taxpayer objTaxpayer = new Taxpayer(nif, fullname, address, telephone, new HashSet<TaxInspector>(0));
			
			/*
			 * 3rd STEP: Add the item to the ArrayList
			 */
			arlTaxpayers.add(objTaxpayer);
			System.out.println("====> Added: " + objTaxpayer.toString());
			System.out.println("");
		}

		if (!arlTaxpayers.isEmpty()) {
			// Insert offices into BD
			for (Taxpayer objTaxpayer : arlTaxpayers) {
				objTaxpayerDAO.addTaxpayer(objTaxpayer.getNif(), objTaxpayer.getFullname(), objTaxpayer.getAddress(),
						objTaxpayer.getTelephone());
			}
		}
		// Finally, list the offices
		objTaxpayerDAO.listTaxpayers();
	}
	
	/**
	 * Get TaxInspectors list from keyboard, insert it into DB and list all TaxInspectors.
	 */
	public static void insertAndListTaxInspectors(TaxInspectorDAO objTaxInspectorDAO, OfficeDAO objOfficeDAO, TaxpayerDAO objTaxpayerDAO) {
		
		ArrayList<TaxInspector> arlTaxInspectors = new ArrayList<TaxInspector>(); // array of TaxInspector
		
		// TaxInspector attributes
		String taxinsDNI;
		String firstName;
		String lastName;
		LocalDate birthday;
		Float commission;
		Office office = null;
		Set<Taxpayer> taxpayers = new HashSet<Taxpayer>(0);
		
		// Auxiliary variables
		String officeCode;
		String taxpayerNif;
		
		
		/*
		 * 1st STEP: We're asking for items until zero is set as dni
		 */
		while (true) {
			// Ask for dni while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				taxinsDNI = IOTools.askString("Enter TaxInspector DNI (zero to exit)");
				for (TaxInspector taxInspector : arlTaxInspectors) {
					if (taxinsDNI.equals(taxInspector.getDni())) {
						bExists = true;
						System.out.println("====> ERROR: DNI already exists");
					}
				}
			} while (bExists);
			
			if (taxinsDNI.equals("0"))
				break;
			
			firstName = IOTools.askStringSpaces("first name");
			lastName = IOTools.askStringSpaces("lastname");
			birthday = IOTools.askDate("birthday", "dd/MM/yyyy");
			commission = IOTools.askFloat("commission % (between 0 and 30)", 0, 30);
			// Associated Office
			do {
				// Try to get an Office by code
				officeCode = IOTools.askString("office code");
				office = objOfficeDAO.getOfficeByCode(officeCode);
				if(office == null) {
					System.out.println("Office not found. Please enter an existent one.");
				}
			} while(office == null);
			
			// Associated Taxpayers
			do {
				taxpayerNif = IOTools.askString("Associate a Taxpayer by NIF (zero to exit)");
				if (taxpayerNif.equals("0")) {
					break;
				}
				Taxpayer taxpayer = objTaxpayerDAO.getTaxpayerByNIF(taxpayerNif);
				if (taxpayer == null) {
					System.out.println("Taxpayer not found. Please enter an existent one.");
				} else {
					taxpayers.add(taxpayer);
				}
			} while (true);
			
			/*
			 * 2nd STEP: We create an object as soon as we have the right
			 * data of an item
			 */
			TaxInspector objTaxInspector = new TaxInspector(taxinsDNI, firstName, lastName, birthday, commission, office,  taxpayers);
			
			/*
			 * 3rd STEP: Add the item to the ArrayList
			 */
			arlTaxInspectors.add(objTaxInspector);
			System.out.println("====> Added: " + objTaxInspector.getDni());
			System.out.println("");
		}
		
		if (!arlTaxInspectors.isEmpty()) {
			// Insert offices into BD
			for (TaxInspector objTaxInspector : arlTaxInspectors) {
				objTaxInspectorDAO.addTaxInspector(objTaxInspector.getDni(), objTaxInspector.getFirstName(), objTaxInspector.getLastName(),
						objTaxInspector.getBirthday(), objTaxInspector.getCommission(), objTaxInspector.getOffice(), objTaxInspector.getTaxpayers());
			}
		}
		
		// Finally, list the TaxInspectors
		objTaxInspectorDAO.listTaxInspectors();
	}
	
	/** LIST */
	
	/** Get a TaxInspector by DNI and list all the Taxpayers under investigation (associated) */
	public static void listTaxpayersByTaxInspector(TaxInspectorDAO objTaxInspectorDAO) {
		String dni;
		do {
			dni = IOTools.askString("Enter TaxInspector DNI (zero to exit)");
			if(dni.equals("0")) {
				break;
			}
			
			TaxInspector taxinspector = objTaxInspectorDAO.getTaxInspectorByDNI(dni);
			
			if(taxinspector == null) {
				System.out.println("TaxInspector not found. Please enter an existent one.");
				continue;
			}
			
			List<Taxpayer> taxpayers = objTaxInspectorDAO.getInvestigatedTaxpayersByInspector(dni);

			System.out.println("Taxpayers under investigation by (" + taxinspector.getDni() + "):" );
			if (!taxpayers.isEmpty()) {
				for (Iterator<Taxpayer> itTaxpayer = taxpayers.iterator(); itTaxpayer.hasNext();) {
					Taxpayer taxpayer  = (Taxpayer) itTaxpayer.next();
					System.out.println(" - Taxpayer : <<NIF: " + taxpayer.getNif() + ">> , <<Fullname: "
							+ taxpayer.getFullname() + ">>\n");
				}
			} else {
				System.out.println("NONE.");
			}
		} while (true);
	}

	/** Print TaxInspectors from the given list */
	public static void listTaxInspectorsFromList(List<TaxInspector> arlTaxInspector) {
		if (arlTaxInspector.isEmpty())
			System.out.println("******** No items found");
		else
			System.out.println("\n***** Start listing TaxInspector ...\n");

		for (Iterator<TaxInspector> itTaxInspector = arlTaxInspector.iterator(); itTaxInspector.hasNext();) {
			TaxInspector objTaxInspector = (TaxInspector) itTaxInspector.next();
			System.out.println(objTaxInspector.toStringDB());
		}
	}
	
	/** Print Taxpayers from the given list */
	public static void listTaxPayersFromList(List<Taxpayer> arlTaxpayer) {
		if (arlTaxpayer.isEmpty())
			System.out.println("******** No items found");
		else
			System.out.println("\n***** Start listing Taxpayers ...\n");

		for (Iterator<Taxpayer> itTaxInspector = arlTaxpayer.iterator(); itTaxInspector.hasNext();) {
			Taxpayer objTaxpayer = (Taxpayer) itTaxInspector.next();
			System.out.println(objTaxpayer.toStringDB());
		}
	}
	
	/** UPDATE */
	
	/** Update an Office by code */
	public static void updateOffice(OfficeDAO objOfficeDAO) {
		String oldCode;
		String newCode;
		boolean exit = false; // Condition to exit the while loop
		
		do {
			oldCode = IOTools.askString("Enter an Office code (zero to exit)");
			if(oldCode.equals("0"))
				break;
			newCode = IOTools.askString("Enter an Office new code");
			
			// Condition will be that the update don't fail
			exit = objOfficeDAO.updateOffice(oldCode, newCode);
			
		} while(!exit);
		
	}
	
	/** DELETE */
	
	/** Delete a selection of Taxpayers (arraylist) by nif from records */
	public static void deleteTaxpayersByNif(TaxpayerDAO objTaxpayerDAO) {
		ArrayList<String> arlTaxpayerNifs = new ArrayList<String>(); // Store nifs instead of Taxpayers
		String nif;
		
		/*
		 * 1st STEP: We're asking for items until zero is set as nif
		 */
		while (true) {
			// Ask for nif while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				nif = IOTools.askString("Enter a taxpayer NIF (zero to exit)");
				for (String nifToDelete : arlTaxpayerNifs) {
					if (nif.equals(nifToDelete)) {
						bExists = true;
						System.out.println("====> ERROR: NIF already added");
					}
				}
			} while (bExists);

			if (nif.equals("0"))
				break;

			/*
			 * 2nd STEP: Ensure that the taxpayer exists in the DB
			 */
			Taxpayer taxpayer = objTaxpayerDAO.getTaxpayerByNIF(nif);
			
			// If the taxpayer don't exist, just ignore it with a message
			if(taxpayer == null) {
				System.out.println("Not an existent taxpayer.");
			} else {
				/*
				 * 3rd STEP: Add the nif to the ArrayList
				 */
				arlTaxpayerNifs.add(nif);
				System.out.println(nif + " added to <<Delete List>>.");
			}
			
		}
		// If the list is not empty, loop though it and delete on cascade
		if (!arlTaxpayerNifs.isEmpty()) {
			for(String taxpayerNif : arlTaxpayerNifs) {
				objTaxpayerDAO.deleteTaxpayer(taxpayerNif);
			}
		}
	}
	
	/** Delete a selection of TaxInspectors (arraylist) by dni from records */
	public static void deleteTaxInspectorsByDni(TaxInspectorDAO objTaxInspectorDAO) {
		ArrayList<String> arlTaxInspectorDnis = new ArrayList<String>(); // Store dnis instead of TaxInspectors
		String dni;
		
		/*
		 * 1st STEP: We're asking for items until zero is set as dni
		 */
		while (true) {
			// Ask for dni while repeated
			Boolean bExists;
			do {
				bExists = false;
				// Ask for items until get zero
				dni = IOTools.askString("Enter a TaxInspector DNI (zero to exit)");
				for (String dniToDelete : arlTaxInspectorDnis) {
					if (dni.equals(dniToDelete)) {
						bExists = true;
						System.out.println("====> ERROR: DNI already added");
					}
				}
			} while (bExists);
			
			if (dni.equals("0"))
				break;
			
			/*
			 * 2nd STEP: Ensure that the TaxInspector exists in the DB
			 */
			TaxInspector taxInspector = objTaxInspectorDAO.getTaxInspectorByDNI(dni);
			// If the TaxInspector don't exist, just ignore it with a message
			if(taxInspector == null) {
				System.out.println("Not an existent taxpayer.");
			} else {
				/*
				 * 3rd STEP: Add the dni to the ArrayList
				 */
				arlTaxInspectorDnis.add(dni);
				System.out.println(dni + " added to <<Delete List>>.");
			}
			
		}
		// If the list is not empty, loop though it and delete on cascade
		if (!arlTaxInspectorDnis.isEmpty()) {
			for(String taxInspectorDni : arlTaxInspectorDnis) {
				objTaxInspectorDAO.deleteTaxInspector(taxInspectorDni);
			}
		}
	}

	/** ------------ HQL CRITERIA ---------------------- */
	
	/** Find and list TaxInspectors with commission greater than a given number */
	public static void findTaxInspectorsByCommission(TaxInspectorDAO objTaxInspectorDAO) {
		Float commission;
		
		commission = IOTools.askFloat("Enter a commission (0 to 30)");
		// Print the list of TaxInspectors
		objTaxInspectorDAO.listTaxInspectorsByCommission_HQL(commission);
		
	}
	
	/** Find and list Taxpayers and the total number, under investigation,  by a TaxInspector (by given dni)*/
	public static void findTaxpayersUnderInvestigationByDNI(TaxInspectorDAO objTaxInspectorDAO) {
		String dni;
		
		dni = IOTools.askString("Enter a TaxInspector DNI (zero to exit)");
		if(dni.equals("0")) {
			System.out.println("Exit.");
			return;
		}
		objTaxInspectorDAO.getInvestigatedTaxpayersByInspector_HQL(dni);
		
	}
}























package com.roldansanchismartinez.actividadevaluable1_pmdm

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    // Pantalla donde se muestran los resultados ('lateinit var' porque le daremos un valor al iniciar la app)
    //private lateinit var screen: TextView

    // Variables para el cálculo
    private var input = "" // Texto actual
    private var operator = "" // El operador actual
    private var operand1 = 0.0 // Primer operando
    private var operand2 = 0.0 // Segundo operando
    private var result = 0.0 // Resultado de la operación

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        /* Inicializamos los componentes */
        // Pantalla
        //screen = findViewById<TextView>(R.id.tv_calculatorScreen)
        // Inicializamos los botones y añadimos acciones a cada botón
        setupListeners()
    }

    /** Establece un Listener para cada botón */
    private fun setupListeners() {

        // Botones numéricos (0-9)
        val numberButtons = listOf(
            findViewById<Button>(R.id.btn_0),
            findViewById<Button>(R.id.btn_1),
            findViewById<Button>(R.id.btn_2),
            findViewById<Button>(R.id.btn_3),
            findViewById<Button>(R.id.btn_4),
            findViewById<Button>(R.id.btn_5),
            findViewById<Button>(R.id.btn_6),
            findViewById<Button>(R.id.btn_7),
            findViewById<Button>(R.id.btn_8),
            findViewById<Button>(R.id.btn_9)
        )

        // Configuramos clicks y asociamos el método "appendNumber()" a cada botón de número
        for ((_, button) in numberButtons.withIndex()) {
            // El parámetro pasado al método es el contenido del propio botón (p.e. btn_1 pasará "1"
            button.setOnClickListener { appendNumber(button.text.toString()) }
        }

        // Configuramos clicks y asociamos el método "setOperator()" a cada botón de operador
        findViewById<Button>(R.id.btn_add).setOnClickListener { setOperator("+") }
        findViewById<Button>(R.id.btn_subtract).setOnClickListener { setOperator("-") }
        findViewById<Button>(R.id.btn_multiply).setOnClickListener { setOperator("*") }
        findViewById<Button>(R.id.btn_divide).setOnClickListener { setOperator("/") }
        findViewById<Button>(R.id.btn_module).setOnClickListener { setOperator("%") }

        // Configuramos clicks y asociamos métodos específicos a cada botón de función específica
        // Clear (borrar)
        findViewById<Button>(R.id.btn_clear).setOnClickListener { clearAll() }
        // Igual
        findViewById<Button>(R.id.btn_equals).setOnClickListener { calculateResult() }
        // Punto (coma) para decimales
        findViewById<Button>(R.id.btn_dot).setOnClickListener { appendDot() }
        // Cambio de signo (+/-)
        findViewById<Button>(R.id.btn_signChange).setOnClickListener { toggleSign() }
    }


    /** Añade el número pulsado al texto en pantalla */
    private fun appendNumber(number: String) {
        input += number
        updateDisplay(input)
        // todo print("Las varibales son: <Input:$input Operador: $operator Operando1: $operand1 Operando2: $operand2 Resultado: $result>\n")
    }

    /** Añade un punto (coma) si el texto actual no tiene uno ya */
    private fun appendDot() {
        if (!input.contains(".")) {
            input += "."
            updateDisplay(input)
        }
    }

    /** Añade el operador seleccionado al texto actual */
    private fun setOperator(selectedOperator: String) {
        if (input.isNotEmpty() || operand1.toString() != input) {
            operand1 = input.toDouble()
            operator = selectedOperator
            input = "" // Limpiar la entrada para el siguiente número
        }
    }

    /** Limpia todos los elementos: input, operator, operand1, operand2 y el result
     * para comenzar desde el principio */
    private fun clearAll() {
        input = ""
        operator = ""
        operand1 = 0.0
        operand2 = 0.0
        result = 0.0
        updateDisplay("0.0")
    }

    /** Cambia el signo del texto actual */
    private fun toggleSign() {
        if (input.isNotEmpty()) {
            input = if (input.startsWith("-")) {
                input.substring(1) // Quitar el signo negativo
            } else {
                "-$input" // Agregar el signo negativo
            }
            updateDisplay(input)
        }
    }

    /** Actualiza el contenido de la pantalla */
    private fun updateDisplay(value: String) {
        val screen = findViewById<TextView>(R.id.tv_calculatorScreen)
        screen.text = value
    }

    /** Calcula el resultado de la operación */
    private fun calculateResult() {
        if (input.isNotEmpty()) {
            operand2 = input.toDouble()

            // Dependiendo del operador, realizamos una operación
            result = when (operator) {
                "+" -> addition(operand1,operand2)
                "-" -> subtraction()
                "*" -> multiplication()
                "/" -> division()
                "%" -> operand1 % operand2
                else -> 0.0
            }

            // Mostrar el resultado
            updateDisplay(result.toString())

            // Reiniciar para el próximo cálculo (el último resultado es el siguiente operand1)
            operand1 = result
            input = ""
            operator = ""
        }
    }

    // Operaciones de suma, resta, multiplicación y división
    private fun addition(op1: Double, op2: Double) = op1 + op2
    private fun subtraction() = operand1 - operand2
    private fun multiplication() = operand1 * operand2
    private fun division() = if (operand2 != 0.0) operand1 / operand2 else Double.NaN


}

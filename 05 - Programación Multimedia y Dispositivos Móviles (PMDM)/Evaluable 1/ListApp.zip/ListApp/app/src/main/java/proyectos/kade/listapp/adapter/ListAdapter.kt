package proyectos.kade.listapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.fragment.app.findFragment
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import proyectos.kade.listapp.databinding.ItemViewBinding
import proyectos.kade.listapp.model.Item
import proyectos.kade.listapp.ui.ListFragment
import proyectos.kade.listapp.ui.ListFragmentDirections

/** Adaptador para la RecyclerView (permite mostrar los diferentes elementos en una lista "infinita" que se "recicla") */
class ListAdapter(var itemList: List<Item>) :
    RecyclerView.Adapter<ListAdapter.ViewHolder>() {

    /** El ViewHolder es el encargado de mostrar cada elemento, se trata de un patrón de diseño */
    class ViewHolder(val binding: ItemViewBinding) : RecyclerView.ViewHolder(binding.root) {
        val checkBox = binding.checkbox
        val itemNameTV = binding.tvItemName
        val editIBTN = binding.ibtnEdit
        val deleteIBTN = binding.ibtnDelete
    }

    /** Método encargado de crear el binding para inflar la vista de los elementos */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    /** Se encarga de enlazar los datos del elemento de una posición concreta (position) de la lista con su vista correspondiente */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder) {
            with(itemList[position]) { val item = this // Para mejorar comprensión
                // Componentes visuales (UI)
                itemNameTV.text = item.name
                checkBox.isChecked = item.checked

                // Listener del botón de editar (desde ListFragment lanza DetailFragment)
                editIBTN.setOnClickListener {
                    // Crea la action para navegar de un fragment a otro
                    val action = ListFragmentDirections.actionListFragmentToDetailFragment(
                        id = item.id!!,
                        name = item.name,
                        photo = item.photo,
                        description = item.description,
                        title = item.name,
                        checked = item.checked
                    )
                    // Llamada para navegar
                    binding.root.findNavController().navigate(action)
                }
                // Listener del botón de borrar
                deleteIBTN.setOnClickListener { currentView ->
                    currentView.findFragment<ListFragment>().delete(item)
                }
                // Listener del checkbox
                checkBox.setOnClickListener { currentView ->
                    item.checked = checkBox.isChecked
                    currentView.findFragment<ListFragment>().insert(item)
                }

            }
        }
    }

    /** Devuelve la cantidad de elementos que tiene la lista itemList, método estándar */
    override fun getItemCount(): Int = itemList.size


}
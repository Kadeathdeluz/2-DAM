package proyectos.kade.listapp.model.data

import androidx.lifecycle.LiveData
import androidx.room.*
import proyectos.kade.listapp.model.Item

/** Interfaz para implementar el Data Access Object - Permite intereccionar con la base de datos */
@Dao
interface ItemDao {
    /** Devuelve el elemento (item) con ID dado */
    @Query("SELECT * FROM item WHERE id = :itemId LIMIT 1")
    fun getItemByID(itemId: Int): LiveData<Item>

    /** Inserta el elemento (item) dado en la base de datos */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: Item)

    /** Elimina el elemento (item) de la base de datos */
    @Delete
    suspend fun delete(item: Item)

    /** Devuelve todos los elementos (item) de la base de datos "SELECT * FROM" */
    @Query("SELECT * FROM item")
    fun getAllItems(): LiveData<List<Item>>
}

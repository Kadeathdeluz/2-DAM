package proyectos.kade.listapp.model.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import proyectos.kade.listapp.model.Item

/** Clase abstracta que permite la conexión con la base de datos Room */
@Database(entities = [Item::class], version = 2, exportSchema = false)
abstract class ItemRoomDatabase : RoomDatabase() {

    /** Obtiene el DAO asociado a la base de datos ItemDao */
    abstract fun getItemDao(): ItemDao

    /** Patrón Singleton de la base de datos */
    companion object {
        @Volatile
        private var INSTANCE: ItemRoomDatabase? = null

        /** Devuelve la instancia de la base de datos de Room */
        fun  getDatabase(context: Context): ItemRoomDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ItemRoomDatabase::class.java,
                    "item_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
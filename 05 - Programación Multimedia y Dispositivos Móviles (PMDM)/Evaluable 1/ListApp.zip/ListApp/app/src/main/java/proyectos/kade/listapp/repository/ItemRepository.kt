package proyectos.kade.listapp.repository

import androidx.lifecycle.LiveData
import proyectos.kade.listapp.model.Item
import proyectos.kade.listapp.model.data.ItemRoomDatabase

/** Clase repositorio que sirve como nivel adicional de abstracción para la conexión con la base de datos */
class ItemRepository(private val db: ItemRoomDatabase) {

    // Obtiene el DAO asociado a la base de datos
    private val itemDao = db.getItemDao()

    /** Obtiene un Item dado su ID */
    fun getItemByID(id: Int): LiveData<Item> = itemDao.getItemByID(id)
    /** Inserta un Item dado */
    suspend fun insert(item: Item) = itemDao.insert(item)
    /** Elimina el Item dado */
    suspend fun delete(item: Item) = itemDao.delete(item)

    /** Devuelve todos los Item */
    fun getAllItems() = db.getItemDao().getAllItems()
}
package proyectos.kade.listapp.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import proyectos.kade.listapp.R

/** Activity que representa la ventana de info (carece de UI propia) */
class InfoActivity : AppCompatActivity(){

    /** Crea la UI de la Activity mediante código */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Como únicamente deseo mostrar info, no creo una UI para la Activity y lo hago mediante código
        val textView = TextView(this).apply {
            // Texto que se mostrará en la Activity con un tamaño de 20f y centrado
            text = context.getString(R.string.info_app)
            textSize = 20f
            gravity = Gravity.CENTER
        }

        // Para utilizar el TextView como contenido de la Activity
        setContentView(textView)
    }
}
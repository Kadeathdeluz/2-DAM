package proyectos.kade.listapp.ui

import android.content.Intent
import android.icu.text.IDNA.Info
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupActionBarWithNavController
import proyectos.kade.listapp.R
import proyectos.kade.listapp.databinding.ActivityMainBinding


/** Activity principal que contiene Navegador de fragmentos (que muestra el fragment de la lista de items) */
class ListActivity : AppCompatActivity() {

    // NavController de fragmentos (permite navegar entre fragmentos)
    private lateinit var navController: NavController


    /** Infla la vista principal, fuerza el modo light e inicializa el navController */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Fuerza el lightmode
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Se vinculan las vistas al binding para accederlas (en lugar de findViewById cada vez)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Permite la navegación entre fragmentos y mostrar el fragmento principal
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment

        navController = navHostFragment.navController

        setupActionBarWithNavController(navController)
    }

    /** Infla el menú personalizado menu_main para mostrar el botón de info */
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)  // Inflar el archivo de menú
        return true
    }

    /** Dependiendo del botón pulsado del menú, se lanza un evento */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.info_button -> {
                // Acción al presionar el botón
                val intent = Intent(this, InfoActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /** Integra la navegación de la ActionBar con la navegación del navController */
    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}

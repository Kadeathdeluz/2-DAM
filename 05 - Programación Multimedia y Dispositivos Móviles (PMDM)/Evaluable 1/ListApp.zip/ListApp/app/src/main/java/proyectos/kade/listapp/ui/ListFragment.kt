package proyectos.kade.listapp.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import proyectos.kade.listapp.R
import proyectos.kade.listapp.adapter.ListAdapter
import proyectos.kade.listapp.databinding.ListViewBinding
import proyectos.kade.listapp.model.Item
import proyectos.kade.listapp.model.data.ItemRoomDatabase
import proyectos.kade.listapp.repository.ItemRepository
import proyectos.kade.listapp.viewmodel.ListViewModel
import proyectos.kade.listapp.viewmodel.ListViewModelFactory

/** Fragment que contiene la Recyclerview que muestra los elementos en forma de lista */
class ListFragment : Fragment() {

    /* Variables MVVM, adaptador de lista y elementos UI */
    lateinit var viewModel: ListViewModel

    private var _binding: ListViewBinding? = null
    private val binding get() = _binding!!

    private lateinit var listAdapter: ListAdapter
    private lateinit var itemList: List<Item>

    private lateinit var recyclerView: RecyclerView
    private lateinit var addFAB: FloatingActionButton

    /** Infla la vista */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = ListViewBinding.inflate(inflater, container, false)
        return binding.root
    }

    /** Vincula los elementos UI y sus componentes, y puebla la lista con los elementos de la base de datos */
    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        /* Vinculación de elementos UI y adaptador */
        recyclerView = binding.recyclerView
        addFAB = binding.fabAddList
        itemList = listOf<Item>()
        listAdapter = ListAdapter(itemList)

        /* Añade el Adapter a la Recyclerview */
        with(recyclerView) {
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(context)
            adapter = listAdapter
        }

        /* Repositorio, Factoría y ViewModel */
        val repository: ItemRepository =
            ItemRepository(ItemRoomDatabase.getDatabase(requireContext()))
        val factory: ListViewModelFactory = ListViewModelFactory(repository)

        viewModel = ViewModelProvider(this,factory)[ListViewModel::class.java]

        /* Muestra todos los elementos de la base de datos y los actualiza cuando cambian */
        viewModel.getAllItems().observe(viewLifecycleOwner) { list ->
            listAdapter.itemList = list
            listAdapter.notifyDataSetChanged()
        }

        // Añade funcionalidad al Floating Action Button (Nuevo elemento)
        addFAB.setOnClickListener {
            val item = Item(
                checked = false,
                name = "Name",
                description = "Generated item ",
                photo = R.drawable.ic_launcher_foreground
            )
            addItem(item)
        }

    }

    /** Abre el DetailFragment para la creación de un nuevo elemento */
    private fun addItem(item: Item) {
        with(item) {
            val action = ListFragmentDirections.actionListFragmentToDetailFragment(
                id = id ?: -1,
                name = name,
                photo = photo,
                checked = checked,
                description = description,
                title = "Add Item"
            )
            findNavController().navigate(action)
        }
    }

    /** Inserta el item mediante el ViewModel */
    fun insert(item: Item) =
        viewModel.insert(item)

    /** Elimina el item dado mediante el ViewModel */
    fun delete(item: Item) =
        viewModel.delete(item)

    /** Cuando la vista se destruye, se libera la vinculación */
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
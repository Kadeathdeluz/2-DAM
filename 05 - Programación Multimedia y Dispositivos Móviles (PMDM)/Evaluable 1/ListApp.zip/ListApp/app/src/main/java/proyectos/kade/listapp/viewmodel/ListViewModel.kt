package proyectos.kade.listapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import proyectos.kade.listapp.model.Item
import proyectos.kade.listapp.repository.ItemRepository

/** El ViewModel es el encargado de mediar entre la UI y la lógica de los datos (forma parte del patrón MVVM) */
class ListViewModel(private val repository: ItemRepository) : ViewModel() {


    /** Devuelve un Item dado su ID */
    fun getItemByID(id: Int): LiveData<Item> =
        repository.getItemByID(id)

    /** Inserta un Item dado */
    fun insert(item: Item) = GlobalScope.launch {
        repository.insert(item)
    }

    /** Elimina un Item dado */
    fun delete(item: Item) = GlobalScope.launch {
        repository.delete(item)
    }

    /** Devuelve todos los Item de la base de datos */
    fun getAllItems() = repository.getAllItems()

}

/** Factoría de ListViewModel que permite crear instancias personalizadas de ViewModel y personalizar sus argumentos (repository en este caso) */
class ListViewModelFactory(private val repository: ItemRepository) : ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(ListViewModel::class.java)){
            @Suppress("UNCHECKED_CAST")
            return ListViewModel(repository) as T
        }
        throw java.lang.IllegalArgumentException("Unknown ViewModel class")
    }
}
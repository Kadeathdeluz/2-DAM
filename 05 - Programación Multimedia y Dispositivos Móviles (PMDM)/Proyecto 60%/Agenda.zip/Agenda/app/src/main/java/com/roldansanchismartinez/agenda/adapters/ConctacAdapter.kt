package com.roldansanchismartinez.agenda.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.roldansanchismartinez.agenda.R
import com.roldansanchismartinez.agenda.models.Contact

/** Adaptador para la lista de contactos */
class ContactAdapter(
    private var contactos: List<Contact>,
    private val onItemClick: (Contact) -> Unit
) : RecyclerView.Adapter<ContactAdapter.ContactViewHolder>() {

    /** ViewHolder para cada elemento de la lista */
    class ContactViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val nombreTextView: TextView = view.findViewById(R.id.textNombre)
        private val telefonoTextView: TextView = view.findViewById(R.id.textTelefono)
        // La ubicación no la vamos a mostrar en la lista, pero sí en los detalles

        // Método para enlazar los datos del contacto con la vista
        fun bind(contacto: Contact, onItemClick: (Contact) -> Unit) {
            nombreTextView.text = contacto.nombre
            telefonoTextView.text = contacto.telefono
            itemView.setOnClickListener { onItemClick(contacto) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ContactViewHolder(view)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contacto = contactos[position]
        holder.bind(contacto, onItemClick)
    }

    override fun getItemCount() = contactos.size

    /** Método para actualizar la lista de contactos */
    fun setContacts(newContacts: List<Contact>) {
        contactos = newContacts
        notifyDataSetChanged()
    }
}
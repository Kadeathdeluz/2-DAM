package com.roldansanchismartinez.agenda.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.roldansanchismartinez.agenda.models.Contact
import kotlinx.coroutines.flow.Flow

@Dao
/** Interfaz que define las operaciones de base de datos para la entidad Contact */
interface ContactDao {

    @Query("SELECT * FROM contacts ORDER BY nombre ASC")
    /** Consulta para obtener todos los contactos ordenados por nombre */
    fun getAllContacts(): Flow<List<Contact>> // Flow para usar LiveData o StateFlow

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    /** Consulta para insertar un contacto */
    suspend fun insertContact(contact: Contact)

    @Delete
    /** Consulta para eliminar un contacto */
    suspend fun deleteContact(contact: Contact)

    @Query("DELETE FROM contacts")
    /** Consulta para eliminar todos los contactos */
    suspend fun deleteAllContacts()

}
package com.roldansanchismartinez.agenda.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.roldansanchismartinez.agenda.models.Contact

@Database(entities = [Contact::class], version = 2, exportSchema = false)
/** Clase abstracta que define la base de datos */
abstract class ContactDatabase : RoomDatabase() {

    abstract fun contactDao(): ContactDao

    /** Patrón Singleton para obtener la instancia de la base de datos */
    companion object {
        @Volatile
        private var INSTANCE: ContactDatabase? = null

        fun getDatabase(context: Context): ContactDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ContactDatabase::class.java,
                    "contact_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}




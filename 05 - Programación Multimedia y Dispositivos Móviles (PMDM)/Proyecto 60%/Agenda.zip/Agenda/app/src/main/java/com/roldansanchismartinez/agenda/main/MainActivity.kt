package com.roldansanchismartinez.agenda.main

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.roldansanchismartinez.agenda.R
import com.roldansanchismartinez.agenda.data.ContactDatabase
import com.roldansanchismartinez.agenda.repository.ContactRepository
import com.roldansanchismartinez.agenda.ui.ContactListFragment
import com.roldansanchismartinez.agenda.viewmodel.ContactViewModel
import com.roldansanchismartinez.agenda.viewmodel.ContactViewModelFactory

/** Actividad principal (únicamente muestra el fragmento de la lista de contactos) */
class MainActivity : AppCompatActivity() {
    private val contactViewModel: ContactViewModel by viewModels<ContactViewModel> {
        val database = ContactDatabase.getDatabase(this)
        val repository = ContactRepository(database.contactDao())
        ContactViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById(R.id.toolbar))

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, ContactListFragment())
            .commit()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_about -> {
                val intent = Intent(this, AboutActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
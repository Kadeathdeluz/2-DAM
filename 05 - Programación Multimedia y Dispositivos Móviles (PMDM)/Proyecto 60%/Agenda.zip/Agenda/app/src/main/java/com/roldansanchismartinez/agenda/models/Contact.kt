package com.roldansanchismartinez.agenda.models

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

/** Data class que representa al contacto */
@Parcelize
@Entity(tableName = "contacts")
/** La clase Contact será tanto parcelizable como una entidad de Room */
data class Contact(
    @PrimaryKey val nombre: String,
    val telefono: String,
    val ubicacion: String // Ubicación en formato lat,long
) : Parcelable
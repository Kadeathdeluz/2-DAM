package com.roldansanchismartinez.agenda.repository

import com.roldansanchismartinez.agenda.data.ContactDao
import com.roldansanchismartinez.agenda.models.Contact
import kotlinx.coroutines.flow.Flow

/** Repositorio para interactuar con la base de datos */
class ContactRepository(private val contactDao: ContactDao) {

    val allContacts: Flow<List<Contact>> = contactDao.getAllContacts()

    suspend fun insert(contact: Contact) {
        contactDao.insertContact(contact)
    }

    suspend fun delete(contact: Contact) {
        contactDao.deleteContact(contact)
    }

    suspend fun deleteAll() {
        contactDao.deleteAllContacts()
    }

}
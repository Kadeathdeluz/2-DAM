package com.roldansanchismartinez.agenda.ui

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.roldansanchismartinez.agenda.R
import com.roldansanchismartinez.agenda.models.Contact

class AgregarContactoDialog(private val listener: (Contact) -> Unit) : DialogFragment() {

    private var coordenadas: String? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireContext())
        val inflater = requireActivity().layoutInflater
        val view = inflater.inflate(R.layout.dialog_agregar_contacto, null)

        // Elementos de la vista
        val etNombre = view.findViewById<EditText>(R.id.etNombre)
        val etTelefono = view.findViewById<EditText>(R.id.etTelefono)
        val tvSeleccionarUbicacion = view.findViewById<TextView>(R.id.tvSeleccionarUbicacion)

        // Listener para seleccionar ubicación
        tvSeleccionarUbicacion.setOnClickListener {
            val mapFragment = SeleccionarUbicacionFragment { ubicacion ->
                coordenadas = ubicacion
                val textoUbicacion = "Ubicación: $ubicacion"
                tvSeleccionarUbicacion.text = textoUbicacion
            }
            mapFragment.show(parentFragmentManager, "SeleccionarUbicacion")
        }

        // Configuración del diálogo
        builder.setView(view)
            .setTitle("Agregar Contacto")
            .setPositiveButton("Guardar") { _, _ ->
                // Valores de los campos
                val nombre = etNombre.text.toString().trim()
                val telefono = etTelefono.text.toString().trim()

                // Todos los campos son obligatorios, en caso de estar vacíos al intentar guardar el contacto, se mostrará un mensaje de error (Toast)
                if (nombre.isNotEmpty() && telefono.isNotEmpty() && coordenadas != null) {
                    val nuevoContacto = Contact(
                        nombre = nombre,
                        telefono = telefono,
                        ubicacion = coordenadas!!
                    )
                    listener(nuevoContacto)
                } else {
                    Toast.makeText(requireContext(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }

        return builder.create()
    }
}

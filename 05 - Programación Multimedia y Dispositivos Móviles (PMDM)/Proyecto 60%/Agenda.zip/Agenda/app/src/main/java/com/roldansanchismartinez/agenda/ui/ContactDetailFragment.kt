package com.roldansanchismartinez.agenda.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.roldansanchismartinez.agenda.R
import com.roldansanchismartinez.agenda.models.Contact
import com.roldansanchismartinez.agenda.utils.Utils

class ContactDetailFragment : Fragment(), OnMapReadyCallback {

    //VARIABLES GLOBALES
    private lateinit var googleMap: GoogleMap
    private var contacto: Contact? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_contact_detail, container, false)
    }

    /* Método para mostrar los detalles del contacto e inicializar el mapa
    * */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val nombreTextView: TextView = view.findViewById(R.id.textNombreDetalle)
        val telefonoTextView: TextView = view.findViewById(R.id.tvTelefono)
        val ubicacionTextView: TextView = view.findViewById(R.id.tvUbicacion)
        val mapFragment: SupportMapFragment = childFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        contacto = arguments?.getParcelable<Contact>("contact_detail")

        // Actualizamos los valores de los campos con los datos del contacto
        contacto?.let {
            nombreTextView.text = it.nombre
            telefonoTextView.text = it.telefono
            val ubicacionTexto = "Ubicación de ${it.nombre}"
            ubicacionTextView.text = ubicacionTexto

        }
    }

    /* Método para inicializar el mapa con la ubicación del contacto
     */
    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        contacto?.let {
            val coordenadas = Utils.parseUbicacion(it.ubicacion) // Llamamos a la función parseUbicacion de nuestra clase Utils
            val (latitud, longitud) = coordenadas ?: Pair(0.0, 0.0) // En caso de ser nulo, usa valores por defecto (para que sea más obvio que hay algún error)
            val ubicacion = LatLng(latitud, longitud)
            val markerOptions = MarkerOptions().position(ubicacion).title("UBI")
            googleMap.addMarker(markerOptions)
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ubicacion, 15f))
        }
    }


    // Companion object con el método para crear una nueva instancia del fragmento con un contacto
    companion object {
        fun newInstance(contacto: Contact): ContactDetailFragment {
            val fragment = ContactDetailFragment()
            val args = Bundle()
            args.putParcelable("contact_detail", contacto)
            fragment.arguments = args
            return fragment
        }
    }


}
package com.roldansanchismartinez.agenda.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.roldansanchismartinez.agenda.R
import com.roldansanchismartinez.agenda.adapters.ContactAdapter
import com.roldansanchismartinez.agenda.data.ContactDatabase
import com.roldansanchismartinez.agenda.models.Contact
import com.roldansanchismartinez.agenda.repository.ContactRepository
import com.roldansanchismartinez.agenda.viewmodel.ContactViewModel
import com.roldansanchismartinez.agenda.viewmodel.ContactViewModelFactory

/** Fragmento que muestra la lista de contactos */
class ContactListFragment : Fragment() {
    private lateinit var contactViewModel: ContactViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ContactAdapter
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var fabDelete: FloatingActionButton

    /* Lista de contactos con algunos ejemplos */
    private val contactosEjemplo = arrayListOf<Contact>(
        Contact("Luke Caminacielos", "902202122", "39.5825062750868, -0.2755038770947139"),
        Contact("María Contodo", "123456789", "39.575501304052914, -0.2782995421288717"),
        Contact("Elpe Nitente", "654321000", "39.57120855597098, -0.27960992844924215"),
        Contact("Cuatro", "444444444", "39.57120855597098, -0.27960992844924215"),
        Contact("Cinco", "555555555", "39.57120855597098, -0.27960992844924215"),
        Contact("Seis", "666666666", "39.57120855597098, -0.27960992844924215"),
        Contact("Siete", "777777777", "39.57120855597098, -0.27960992844924215"),
        Contact("Ocho", "888888888", "39.57120855597098, -0.27960992844924215"),
        Contact("EJEMPLO", "000000000", "39.57120855597098, -0.27960992844924215")
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_contact_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val database = ContactDatabase.getDatabase(requireContext())
        val repository = ContactRepository(database.contactDao())
        val factory = ContactViewModelFactory(repository)
        contactViewModel = ViewModelProvider(this, factory)[ContactViewModel::class.java]

        // Inicializar las vistas
        recyclerView = view.findViewById(R.id.recyclerViewContacts)
        fabAdd = view.findViewById(R.id.fabAddContact)
        fabDelete = view.findViewById(R.id.fabDeleteContact)

        val contactos = contactViewModel.allContacts.asLiveData().value

        // Configurar el adaptador y el RecyclerView, define el funcionamiento de los elementos
        adapter = ContactAdapter(contactos ?: arrayListOf()) { contacto ->
            // Manejar el clic en un contacto
            val fragment = ContactDetailFragment.newInstance(contacto)
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit()
        }

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        // Observa los cambios en la lista de contactos y actualiza el adapter y la vista
        contactViewModel.allContacts.asLiveData().observe(viewLifecycleOwner) { contacts ->
            // Cuando la lista de contactos cambie, actualizamos el adapter
            adapter.setContacts(contacts)
        }

        // Funcionalidad del click del FAB Añadir (añade un nuevo contacto)
        fabAdd.setOnClickListener {
            val dialog = AgregarContactoDialog { nuevoContacto ->
                // Inserta el contacto en la base de datos
                // además, al cambiar la lista, ésta se actualiza en el adapter y se ve reflejado en la vista
                // ya que como está siendo observada, se vuelve a cargar la lista de contactos
                contactViewModel.insert(nuevoContacto)
            }
            dialog.show(parentFragmentManager, "AgregarContactoDialog")

        }

        // Funcionalidad del click del FAB Borrar (borra todos los contactos)
        fabDelete.setOnClickListener {
            // Lanzamos un diálogo y si se confirma, se borran todos los contactos
            AlertDialog.Builder(requireContext())
                .setTitle("Eliminar todos los contactos")
                .setMessage("¿Estás seguro de que quieres eliminar todos los contactos?")
                .setPositiveButton("Sí") { _, _ ->
                    contactViewModel.deleteAll()
                }.setNegativeButton("No", null)
                .show()

        }

    }
}
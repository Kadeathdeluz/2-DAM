package com.roldansanchismartinez.agenda.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.roldansanchismartinez.agenda.R

class SeleccionarUbicacionFragment(private val listener: (String) -> Unit) : DialogFragment(),
    OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private var selectedLocation: LatLng? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_seleccionar_ubicacion, container, false)
    }

    /* Método para inicializar el mapa y el botón de confirmación
    * */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.mapView) as SupportMapFragment
        mapFragment.getMapAsync(this)

        view.findViewById<Button>(R.id.btnConfirmarUbicacion).setOnClickListener {
            selectedLocation?.let {
                listener("${it.latitude},${it.longitude}")
                dismiss()
            } ?: Toast.makeText(requireContext(), "Selecciona una ubicación", Toast.LENGTH_SHORT).show()
        }
    }

    /* Al cargar el mapa permite seleccionar la ubicación del contacto
    * */
    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Movemos la cámara a España (aproximadamente)
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(40.4087843597398, -3.841713124903027), 5f))
        googleMap.setOnMapClickListener { latLng ->
            googleMap.clear()
            googleMap.addMarker(MarkerOptions().position(latLng).title("Ubicación seleccionada"))
            selectedLocation = latLng
        }
    }
}
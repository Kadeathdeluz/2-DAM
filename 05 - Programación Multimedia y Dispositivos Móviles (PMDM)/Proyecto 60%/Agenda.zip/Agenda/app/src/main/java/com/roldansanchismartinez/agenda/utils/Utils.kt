package com.roldansanchismartinez.agenda.utils

class Utils {

    companion object {
        /* Método para dividir la ubicación en latitud y longitud
        * */
        fun parseUbicacion(ubicacion: String): Pair<Double, Double>? {
            val partes = ubicacion.split(",")
            return if (partes.size == 2) {
                try {
                    val latitud = partes[0].toDouble()
                    val longitud = partes[1].toDouble()
                    Pair(latitud, longitud)
                } catch (e: NumberFormatException) {
                    null // Retorna null si hay un error en la conversión
                }
            } else {
                null // Retorna null si la cadena no tiene el formato correcto
            }
        }
    }
}
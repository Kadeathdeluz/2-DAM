package roldansanchismartinez.practica3

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Log onCreate
        Log.i("CicloDeVida", "Ingresa a onCreate")
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onStart() {
        super.onStart()
        //Log onStart
        Log.i("CicloDeVida", "Ingresa a onStart")
    }

    override fun onResume() {
        super.onResume()
        //Log onResume
        Log.i("CicloDeVida", "Ingresa a onResume")
    }

    override fun onPause() {
        super.onPause()
        //Log onPause
        Log.i("CicloDeVida", "Ingresa a onPause")
    }

    override fun onStop() {
        super.onStop()
        //Log onStop
        Log.i("CicloDeVida", "Ingresa a onStop")
    }

    override fun onRestart() {
        super.onRestart()
        //Lor onRestart
        Log.i("CicloDeVida", "Ingresa a onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        //Lor onDestroy
        Log.i("CicloDeVida", "Ingresa a onDestroy")
    }
}
